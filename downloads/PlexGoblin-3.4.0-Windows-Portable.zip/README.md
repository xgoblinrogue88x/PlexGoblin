<p align="center">
  <img src="assets/plex-goblin.png" width="144" alt="Plex Goblin icon">
</p>

# Plex Goblin

Plex Goblin is an unofficial Windows utility that combines runtime-only Plex
playback blocking, temporary access timers, and the Stream Goblin/Monitor
Goblin workflow in one dark graphical application.

It does not require Python, an installer, a separate worker window, or
administrator access.

## Features

- Block selected shared Plex users only while Plex Goblin is running.
- Stop both current playback and new playback attempts from blocked users.
- Apply a timed block that automatically allows a user when its countdown ends.
- Keep the Plex server owner protected from selection.
- Give each Stream Goblin target a custom minimum and maximum playback time.
- Roll a fresh random timer for each new playback and count only playing time.
- Pause countdowns when playback pauses and reroll when the media changes.
- Display live Monitor Goblin countdown bars, activity, and funny log messages.
- Run silently in the Windows notification area and optionally start at sign-in.
- Reopen the complete GUI by double-clicking the tray icon.
- Store active settings and logs in the portable `Data` folder.

## Safety model

The User Access feature does not change Plex library sharing, account access,
labels, restrictions, download permissions, friends, media files, or the Plex
database. It watches the local server and terminates validated playback
sessions belonging to users selected in the in-memory blocklist.

User Access blocks and auto-allow timers are never saved. Exiting Plex Goblin,
a program crash, Windows shutdown, or power loss removes the in-memory blocklist
automatically. Stream Goblin target preferences and time ranges are saved so
they can resume during the next run, but those preferences are not Plex sharing
restrictions.

## Requirements

- Windows 10 or Windows 11
- Windows PowerShell 5.1
- Plex Media Server running on the same Windows PC
- A Plex server-owner account
- Tautulli on the same PC for Stream Goblin and Monitor Goblin features

Plex Goblin only accepts a loopback Tautulli address: `localhost`, `127.0.0.1`,
or `::1` over HTTP or HTTPS.

## Install and run

1. Use the provided Plex Goblin preview ZIP.
2. Extract the complete folder somewhere writable and permanent, such as
   Documents. Do not install it under Program Files.
3. Double-click `Start Plex Goblin.cmd`.
4. Optionally run `Create Desktop Shortcut.cmd` once.
5. Open the Stream + Monitor Goblin tab and configure the local Tautulli API
   key if it was not imported from an earlier installation.

See [README.txt](README.txt) for the complete operating and safety guide.

## Tray mode and Windows autostart

Enable **Start with Windows (silent to tray)** on the User Access tab or from
the tray menu. Plex Goblin will start after the current Windows account signs
in, without showing its main window or a command prompt.

- Double-click the tray icon to open Plex Goblin.
- Minimize the window or click its X to hide it without stopping the watchers.
- Choose **Exit and Allow Everyone** to stop both watchers and clear all
  temporary User Access blocks.
- Launching the desktop shortcut while Plex Goblin is already running restores
  the existing window rather than starting a second copy.

Windows may initially place the icon behind the up-arrow beside the clock. It
can be dragged from that overflow area onto the visible taskbar.

Autostart is implemented with a per-user Windows Startup shortcut rather than
a service. Windows services cannot reliably display an interactive tray icon.
The shortcut stores only the local path to `PlexGoblin.ps1`; it contains no API
keys, Plex tokens, user information, or server identifier.

## Portable data and privacy

Runtime files are created under `Data` beside the application. This includes
encrypted API keys, settings, status, logs, and the single-instance lock. API
keys are protected with Windows Data Protection for the current Windows user.

The repository's `.gitignore` blocks runtime data while retaining only
`Data/README.txt`. Do not force-add files from `Data`, and never publish a ZIP
made from an installation that has already been run. Use the official Public
Clean release asset instead.

The Public Clean package contains no user names, email addresses, server IDs,
tokens, API keys, saved server addresses, target settings, custom time ranges,
status files, logs, locks, or recovery files.

## Updating

Exit Plex Goblin from the tray menu or the green GUI button. Replace the
application files with the new release while keeping the existing `Data`
folder. If the application folder is moved, disable and re-enable Windows
autostart so its shortcut receives the new path.

## Project files

| File | Purpose |
| --- | --- |
| `PlexGoblin.ps1` | Main GUI, Plex session controls, timers, tray, and autostart |
| `StreamGoblinEngine.ps1` | Stream Goblin and Monitor Goblin engine/UI |
| `Start Plex Goblin.cmd` | Normal Windows launcher |
| `Create Desktop Shortcut.cmd` | Creates the optional desktop shortcut |
| `PlexGoblin.ico` | Windows application and tray icon |
| `Data/README.txt` | Keeps the portable data folder present without private data |
| `LICENSE` | MIT terms with the Commons Clause no-sale condition |

## Troubleshooting

- If the tray icon is missing, check the up-arrow beside the Windows clock.
- Do not run the old `C:\StreamGoblin\worker.py` alongside Plex Goblin.
- Logs are written to `Data\PlexGoblin.log` and `Data\StreamGoblin\Logs`.
- If autostart points to an old location, turn it off and back on from Plex
  Goblin after moving the folder.

## License

Plex Goblin is source-available under the MIT License with the Commons Clause.
You may use, copy, modify, and redistribute it, but you may not sell Plex
Goblin itself or a product or service whose value comes entirely or
substantially from Plex Goblin. See [LICENSE](LICENSE) for the complete terms.

Because the license restricts selling the software, it does not meet the Open
Source Initiative definition of "open source." Please describe the project as
**source-available**, not open-source.

## Disclaimer

Plex Goblin is an independent, unofficial community project. It is not
affiliated with, endorsed by, or sponsored by Plex or Tautulli. Plex and
Tautulli names and marks belong to their respective owners.

## Windows portable preview (3.4.0-preview)

The window now resizes down to 420 x 560 at 100% Windows text scaling.
Buttons wrap, grids grow with the window, and rows are taller for remote touch use.
On smaller windows the Stream page offers Targets, Monitor, and Activity views
inside the same window; at wider sizes they appear side by side. Compact mode
shortens inline help; hover the heading for its full guidance. Select an
account to read its email and shared libraries below the grid.

For an S25 Ultra remote session, fit the remote desktop to the phone and try
landscape for more space. Windows scaling and the remote desktop resolution
affect usable space. This is a Windows desktop update, not an Android app.

Extract into a fresh writable folder and launch `Start Plex Goblin.cmd`.
Keep an existing installation and its Data folder backed up. Do not copy its
runtime lock files into this folder. Keys remain bound to the Windows user/PC.

Offline parsing and source checks do not replace Windows PowerShell 5.1 GUI,
tray, high-DPI, and live playback verification.

### Groove Goblin theme and Windows portable packaging

Blue-black surfaces, slate inputs, green headings, purple action buttons, fully
painted dark tabs, themed notifications and tray menus replace the light UI
surfaces. Native dark scrollbars/title bars are requested on supported Windows
builds; Windows accessibility/contrast settings can override native chrome.

Double-click `Launch Plex Goblin.vbs` for a console-free launch (Windows Script
Host must be enabled). `Start Plex Goblin.cmd` remains the fallback launcher.

No installer, admin rights, Python, or downloaded UI library is required. Keep
all supplied files together in a writable folder. Active data stays in `Data`
beside the app; existing legacy data is copied without overwriting. Exit fully
before moving the folder. DPAPI credentials must be re-entered on another
Windows account/PC. Plex and local Tautulli remain separate prerequisites.
Desktop shortcuts and sign-in startup are optional and reference the folder;
recreate them after moving it.

For Windows verification, run `powershell.exe -NoProfile -STA -ExecutionPolicy
Bypass -File tools\Test-WindowsUi.ps1`. This offline check builds the real UI
with dummy rows, resizes it, checks action visibility, and saves bitmap captures
under `Data/UiChecks`; it never connects to Plex/Tautulli. Run at 100%, 125% and
150% Windows scaling. This Windows check has not been executed on the Linux
build host.

Build a clean Windows ZIP with `powershell.exe -NoProfile -ExecutionPolicy
Bypass -File tools\Build-WindowsPortable.ps1`. It stages an explicit file list
and includes only `Data/README.txt`, even when run from an installed folder.

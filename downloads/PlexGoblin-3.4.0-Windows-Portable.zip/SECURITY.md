# Security policy

## Supported version

Security fixes currently target Plex Goblin 3.2.x.

## Reporting a vulnerability

Please use GitHub's private vulnerability-reporting feature instead of opening
a public issue containing sensitive details. Repository owners can enable it
under **Settings → Security → Private vulnerability reporting**.

Do not include Plex tokens, Tautulli API keys, server identifiers, user email
addresses, logs, configuration files, screenshots containing personal data, or
the contents of the `Data` folder in a public issue.

## Credential handling

Plex Goblin reads the Plex owner token from the current user's local Plex
registry settings when available. Manually supplied Plex tokens and Tautulli
API keys are protected with Windows Data Protection for the current Windows
user. The plaintext secrets are not written to configuration or log files.

## Network boundary

Plex operations are limited to local Plex server reads, owner-authorized shared
user data from Plex, and termination of a validated local playback session.
Tautulli access is restricted to loopback addresses on the same PC.


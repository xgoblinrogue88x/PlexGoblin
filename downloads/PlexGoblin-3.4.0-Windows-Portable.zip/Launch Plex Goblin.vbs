' Portable, no-console launcher. No registration or installation is performed.
Option Explicit
Dim shell, fso, appFolder, powershell, script, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appFolder = fso.GetParentFolderName(WScript.ScriptFullName)
powershell = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")
script = fso.BuildPath(appFolder, "PlexGoblin.ps1")
command = Chr(34) & powershell & Chr(34) & " -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File " & Chr(34) & script & Chr(34)
shell.CurrentDirectory = appFolder
shell.Run command, 0, False

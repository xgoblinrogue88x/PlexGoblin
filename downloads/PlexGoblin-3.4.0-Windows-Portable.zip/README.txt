PLEX GOBLIN 3.4.0 WINDOWS PORTABLE PREVIEW
=================

Plex Goblin combines three tools in one dark Windows application:

  - User Access: the former Plex Pause runtime-only playback blocker.
  - Stream Goblin: random per-playback timers that terminate selected streams.
  - Monitor Goblin: live countdown bars, playback state, and Goblin activity.

No Python installation or separate command window is required.

This Windows portable preview uses the Groove Goblin palette: blue-black,
slate, bright green headings, and purple primary actions. The entire tab
surface, dialogs and tray menu are painted dark; Windows native dark chrome
is requested where supported. No installer, Python or administrator needed.
Double-click Launch Plex Goblin.vbs for no console window, or use the CMD
launcher if Windows Script Host is disabled.
Windows PowerShell 5.1 and .NET Framework are built into supported Windows.
All active settings/logs stay in Data beside this application. Shortcuts and
Windows startup are optional and are created only when you request them.
Moving to another PC/account requires re-entering encrypted credentials.
Close via Exit and Allow Everyone before moving the whole folder.

This preview adds a responsive dark layout for small remote desktops.
The minimum window is 420 x 560 at 100% Windows text scaling. On narrow
windows, use Targets / Monitor / Activity inside the Stream tab. Larger
buttons, taller rows, wrapping action bars, and flexible grids improve
remote touch use. Select an account to see email and library details.
Use landscape or fit the remote desktop to your phone for more room.
This remains a Windows app viewed through your remote desktop client.
Windows PowerShell 5.1 GUI/high-DPI verification is still required.

Version 3.2.0 adds a notification-area mode and optional silent start at Windows
sign-in. Double-click the tray icon to reopen the complete interface.

Version 3.1.1 kept the User Access control row, including "Timed Block...",
visible when the application is resized or maximized.

Version 3.1.0 also fixed the Windows "path is not of a legal form" error that
prevented changed time ranges and Tautulli API keys from being saved in 3.0.1.


START IT

1. Extract the complete PlexGoblin folder to a writable, permanent location
   on the Windows PC running Plex. Documents is a good choice. Do not use
   Program Files.
2. Make sure Plex Media Server and Tautulli are running.
3. Double-click "Start Plex Goblin.cmd".
4. To create the proper desktop shortcut and icon, double-click
   "Create Desktop Shortcut.cmd" once.

Keep the extracted folder in its permanent location after creating the
shortcut. The shortcut points to that folder. When installing a future update,
replace the application files but keep the Data folder.


WINDOWS AUTOSTART AND THE TRAY ICON

Plex Goblin uses a normal per-user notification-area app, not a Windows
service. Windows services cannot reliably display a tray icon or open an
interactive GUI. This design requires no administrator access and starts after
this Windows account signs in.

To enable it, check "Start with Windows (silent to tray)" on the User Access
tab, or right-click the Plex Goblin tray icon and choose "Start with Windows".
At the next sign-in Plex Goblin starts with no window or command prompt. Its
playback watchers run in the background using the saved Stream Goblin settings.

  - Double-click the tray icon to open the full GUI.
  - Click the minimize button or window X to hide the GUI without stopping it.
  - Choose "Exit and Allow Everyone" from the tray menu, or click the green
    button in the GUI, to stop Plex Goblin completely.
  - Opening the desktop shortcut while it is already running restores the
    existing GUI instead of starting a second copy.

Windows may initially place new notification icons behind the small up-arrow
beside the clock. If so, open that overflow area and drag Plex Goblin onto the
visible part of the taskbar.

Autostart creates only this shortcut in the current Windows user's Startup
folder:

  Plex Goblin.lnk

It contains the path to PlexGoblin.ps1 and no Plex token, Tautulli key, user
list, or server ID. Disable autostart before moving the PlexGoblin folder, then
enable it again afterward so the shortcut receives the new path.


USER ACCESS + TIMERS TAB

Check a shared Plex account to stop its current and new playback sessions for
as long as Plex Goblin remains open. The Plex server owner is never listed as a
target.

For a temporary timed block:

1. Select a shared account row.
2. Click "Timed Block...".
3. Enter 1 to 10,080 minutes, then click "Block Now".
4. The account is blocked immediately and the table shows a live countdown.
5. When the countdown reaches zero, that account is automatically allowed.

Unchecking a user allows them early and cancels their timer. Starting another
timer for the same user replaces the previous countdown.

The access blocklist and auto-allow timers exist only in memory. Hiding the
window to the tray keeps them active because Plex Goblin is still running:

  - Exit and Allow Everyone: everyone is allowed immediately.
  - Program crash: everyone is allowed immediately.
  - PC shutdown or power loss: no blocked setting remains.
  - Start it again: every account starts unchecked and allowed.

This tab never changes library sharing, labels, restrictions, download
permissions, friends, Plex users, the Plex database, or media files. Users can
still browse. A blocked play attempt may run briefly before the local server
stops it. Offline downloads remain unaffected.


STREAM + MONITOR GOBLIN TAB

Stream Goblin preserves the behavior of the supplied controller, worker, and
monitor inside the graphical application:

  - Enable or disable individual Plex/Tautulli usernames.
  - Set a minimum and maximum random duration for each target.
  - Roll a fresh random duration for every new playback.
  - Count only actual PLAYING time.
  - Freeze the countdown while playback is paused.
  - Reroll when media changes within a reused session.
  - Recheck that the target is enabled immediately before every strike.
  - Terminate the identified session through the local Tautulli API.
  - Show roll, remaining time, state, and a live graphical progress bar.
  - Show the funny Goblin notifications and today's activity log in the app.
  - Write status.json for compatibility with the original monitor data.
  - Keep daily Goblin logs and remove only matching logs older than seven days.

Changes in the target table take effect after clicking "Save Target Settings".
"Disable All" saves every target as disabled. "Add Username..." supports a
Tautulli username that is not present in the shared-user list.

The Enable box must be checked for every account Stream Goblin should watch.
After checking or unchecking accounts, click "Save Target Settings". An awake
Stream Goblin with no enabled target will correctly show no countdowns and
will not terminate anything.

To change a user's random timer range, select the user and click "Change
Times..." (or double-click that user's row). Enter the minimum and maximum
minutes and click "Save Time Range". The new range is saved immediately.
The shaded Min/Max cells can also be edited directly; click "Save Target
Settings" afterward. Imported ranges remain unchanged until you save new ones.

The configurable playback message is what a user may see when the Goblin
strikes. If a user is also blocked on the User Access tab, that immediate block
takes priority over the random Stream Goblin countdown.

Stream Goblin runs inside Plex Goblin and therefore stops when the application
exits. Hiding the window to the tray does not stop it. Its enabled targets and
minute ranges are intentionally saved, just as
they were by the original Stream Goblin controller, so they are ready on the
next launch. These saved target preferences are not Plex sharing restrictions.

Once a valid Tautulli connection is saved, Stream Goblin wakes automatically
whenever Plex Goblin opens. "Stop Stream Goblin" puts it to sleep for the rest
of the current run; "Start Stream Goblin" wakes it again. Closing the whole app
always stops it, and opening the app again starts a newly configured run.


TAUTULLI SETUP AND AUTOMATIC IMPORT

On first launch, Plex Goblin checks for the supplied tool's original setup at:

  C:\StreamGoblin\config.json

If found, it imports the Tautulli URL, target usernames, enabled states, random
minute ranges, playback message, API key, and existing log files. It does not
modify or delete the old C:\StreamGoblin files. The imported API key is stored
with Windows Data Protection and can only be decrypted by the same Windows
user on the same PC. The new config.json deliberately contains no API key.

If automatic import is unavailable, open the Stream + Monitor Goblin tab,
click "Configure Tautulli", and enter:

  Tautulli URL: http://127.0.0.1:8181
  API key:      Tautulli > Settings > Web Interface > API key

Plex Goblin accepts only a loopback Tautulli address: localhost, 127.0.0.1, or
::1 over HTTP or HTTPS. "Test & Save" performs a read-only activity request
before saving the encrypted key.

Do not run the old C:\StreamGoblin\worker.py at the same time. Plex Goblin
detects it and keeps the integrated worker asleep until the old command window
is closed, preventing two workers from attacking the same stream.


PORTABLE DATA, LOGS, AND FIRST-RUN MIGRATION

All active Plex Goblin data is stored beside the application under:

  PlexGoblin\Data

Important files include:

  Data\PlexGoblin.log                       application/watcher diagnostics
  Data\PlexGoblin.lock                      single-instance runtime lock
  Data\token.dat                            encrypted Plex owner token, if needed
  Data\StreamGoblin\config.json             URL, message, and target preferences
  Data\StreamGoblin\tautulli-key.dat        encrypted Tautulli API key
  Data\StreamGoblin\status.json             integrated monitor status
  Data\StreamGoblin\Logs\... GoblinLog.txt  daily Stream Goblin activity logs

Version 3.1.0 no longer writes active data to %LOCALAPPDATA%\PlexPause. On its
first launch, it safely copies recognized settings, encrypted keys, safety
records, and logs from that old location into the portable Data folder. It
never moves, edits, or deletes the old files, and it never imports lock or
temporary files. Existing Stream Goblin targets and time ranges are preserved.

After one successful 3.1.0-or-later launch, confirm that your targets, times, and
Tautulli connection appear correctly. Then close Plex Goblin. If there is no
version-1 recovery warning, you may delete the old:

  %LOCALAPPDATA%\PlexPause

Do not delete PlexGoblin\Data. It now travels with the application and must be
kept when updating or moving the PlexGoblin folder. The encrypted API keys can
be moved on the same PC under the same Windows account. On another PC or under
another Windows account, Windows Data Protection will require the keys again.

The logs record usernames, media titles, playback states, timer rolls, strikes,
and errors. They never record either API token. Daily files matching the exact
Goblin log filename pattern are retained for seven days. Unrelated files are
never removed by log cleanup.


PLEX TOKEN

Plex Goblin normally reads the owner token and server ID from the current
Windows user's Plex Media Server registry settings. It never asks for the Plex
password. If Plex runs under another Windows account, it may ask for the token.

To obtain it using Plex's documented method:

1. Open Plex Web and browse to a movie or episode you own.
2. Open the three-dot menu and choose "Get Info".
3. Click "View XML".
4. Copy only the value after "X-Plex-Token=" in the browser address.
5. Paste that value into Plex Goblin.

The manually entered token is protected with Windows Data Protection.


VERSION 1 SAFETY CHECK

Version 1 of Plex Pause used persistent Plex restrictions and required a later
restore. Plex Goblin never uses that design. If it finds an active or unreadable
version-1 recovery record in the portable Data folder or the previous AppData
location during migration:

  PlexGoblin\Data\state.json
  PlexGoblin\Data\Recovery\active-USERID.json

it refuses to start and changes nothing. Restore those users with version 1 or
in Plex Web first. Plex Goblin never deletes old recovery data automatically.


NETWORK AND SAFETY BOUNDARIES

Plex operations are limited to reading the local server/account/session data,
reading the owner's shared-user information from plex.tv, and terminating one
validated local playback session. User Access makes no POST, PUT, PATCH, or
DELETE request and never writes a Plex setting.

Stream Goblin communicates only with the configured loopback Tautulli server.
It reads get_activity and posts terminate_session for one validated session ID.
It does not change Plex libraries, sharing, user accounts, or the Plex database.

Exiting Plex Goblin always ends both playback watchers. User Access immediately
fails open. Stream Goblin target preferences remain saved but cannot terminate
anything while the application is closed.


PUBLIC DISTRIBUTION PRIVACY

The official Public Clean ZIP contains only the program, icon, launchers,
documentation, and an otherwise empty Data folder. It contains no Plex users,
email addresses, server identifiers, tokens, Tautulli API keys, saved server
addresses, target settings, custom time ranges, status files, logs, locks, or
recovery files.

After Plex Goblin has been run, its Data folder intentionally contains the
local owner's settings and encrypted keys. Do not make a public ZIP from an
installed copy. Redistribute the original Public Clean ZIP instead.


LICENSE

Plex Goblin is source-available under the MIT License with the Commons Clause.
You may use, copy, modify, and redistribute it, but you may not sell Plex
Goblin itself or a product or service whose value comes entirely or
substantially from Plex Goblin. See the included LICENSE file for the complete
terms. Because selling is restricted, this is source-available rather than an
Open Source Initiative-approved open-source project.

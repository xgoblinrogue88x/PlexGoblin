# Changelog

## 3.4.0-preview — Windows portable theme

- Match Groove Goblin's blue-black/slate, green and purple palette.
- Fully paint tab strips and borders; theme inputs, notifications, tray menus, and supported Windows chrome.
- Keep compact responsive layouts, timers and all playback protections.
- Add Windows-only offline UI checks and clean portable packaging scripts.
- No installer or Python runtime; data stays beside the app. Windows visual checks remain pending.

## 3.3.0-preview

- Replace fixed page geometry with docked, resizing layouts and wrapping toolbars.
- Support smaller remote desktop windows with 40-pixel buttons and 36-pixel rows.
- Switch Stream controls between a wide dashboard and compact Targets / Monitor / Activity views.
- Keep Timed Block and explicit Exit reachable; show selected account details below the grid.
- Preserve playback logic, storage, owner protection, tray behavior and credentials.
- Windows GUI/high-DPI validation remains pending.

## 3.2.0

- Added a Windows notification-area icon and tray menu.
- Added optional silent autostart at Windows sign-in without administrator
  access or a visible command window.
- Added double-click tray restoration and second-launch window activation.
- Changed minimize and window-X behavior to hide the GUI while watchers keep
  running.
- Added an explicit **Exit and Allow Everyone** action for complete shutdown.
- Added Public Clean packaging and privacy safeguards.

## 3.1.1

- Kept the User Access control row and **Timed Block** button visible after
  resizing or maximizing the application.

## 3.1.0

- Moved active application data into the portable `Data` folder.
- Added safe, copy-only first-run migration from the previous AppData location.
- Fixed atomic configuration writes that caused a Windows “path is not of a
  legal form” error.
- Restored saving of Stream Goblin time ranges and the Tautulli API key.

## 3.0.0

- Renamed Plex Pause to Plex Goblin.
- Integrated Stream Goblin and Monitor Goblin into the graphical application.
- Added per-user random playback ranges, live countdown bars, activity logs,
  and graphical Tautulli configuration.


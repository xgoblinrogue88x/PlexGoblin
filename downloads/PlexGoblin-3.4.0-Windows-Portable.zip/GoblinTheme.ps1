﻿# Windows PowerShell 5.1 / .NET Framework; no downloaded UI dependencies.
if (-not ('PlexGoblin.GoblinTabs' -as [type])) {
    Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace PlexGoblin {
    public static class Palette {
        public static readonly Color Background = ColorTranslator.FromHtml("#0a1117");
        public static readonly Color Panel = ColorTranslator.FromHtml("#131d27");
        public static readonly Color Surface = ColorTranslator.FromHtml("#1a2530");
        public static readonly Color Input = ColorTranslator.FromHtml("#202c38");
        public static readonly Color Line = ColorTranslator.FromHtml("#31404e");
        public static readonly Color Text = ColorTranslator.FromHtml("#e9f2f4");
        public static readonly Color Green = ColorTranslator.FromHtml("#71f28b");
        public static readonly Color Purple = ColorTranslator.FromHtml("#cc75ff");
    }
    // Paint the entire tab surface, including the unused strip and native border.
    // Native selection, keyboard navigation, page layout and accessibility remain.
    public class GoblinTabs : TabControl {
        public GoblinTabs() {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Palette.Background; ForeColor = Palette.Text;
        }
        protected override void OnPaintBackground(PaintEventArgs e) { e.Graphics.Clear(Palette.Background); }
        protected override void OnPaint(PaintEventArgs e) {
            e.Graphics.Clear(Palette.Background);
            for (int i = 0; i < TabCount; i++) {
                Rectangle r = GetTabRect(i);
                bool selected = i == SelectedIndex;
                using (Brush b = new SolidBrush(selected ? ColorTranslator.FromHtml("#46205f") : Palette.Surface))
                    e.Graphics.FillRectangle(b, r);
                if (selected) using (Brush b = new SolidBrush(Palette.Purple))
                    e.Graphics.FillRectangle(b, r.Left, r.Bottom - 3, r.Width, 3);
                TextRenderer.DrawText(e.Graphics, TabPages[i].Text, Font, r,
                    selected ? Palette.Text : ColorTranslator.FromHtml("#9eb0bd"),
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
                if (selected && Focused) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(r, -5, -5), Palette.Text, Palette.Surface);
            }
        }
        protected override void OnSelectedIndexChanged(EventArgs e) { base.OnSelectedIndexChanged(e); Invalidate(); }
    }
    public class GoblinMenuColors : ProfessionalColorTable {
        public override Color ToolStripDropDownBackground { get { return Palette.Panel; } }
        public override Color ImageMarginGradientBegin { get { return Palette.Panel; } }
        public override Color ImageMarginGradientMiddle { get { return Palette.Panel; } }
        public override Color ImageMarginGradientEnd { get { return Palette.Panel; } }
        public override Color MenuBorder { get { return Palette.Line; } }
        public override Color MenuItemBorder { get { return Palette.Purple; } }
        public override Color MenuItemSelected { get { return Palette.Input; } }
        public override Color MenuItemSelectedGradientBegin { get { return Palette.Input; } }
        public override Color MenuItemSelectedGradientEnd { get { return Palette.Input; } }
        public override Color MenuItemPressedGradientBegin { get { return Palette.Input; } }
        public override Color MenuItemPressedGradientEnd { get { return Palette.Input; } }
        public override Color SeparatorDark { get { return Palette.Line; } }
        public override Color SeparatorLight { get { return Palette.Line; } }
        public override Color StatusStripGradientBegin { get { return Palette.Panel; } }
        public override Color StatusStripGradientEnd { get { return Palette.Panel; } }
        public override Color CheckBackground { get { return Palette.Input; } }
        public override Color CheckSelectedBackground { get { return Palette.Input; } }
        public override Color CheckPressedBackground { get { return Palette.Input; } }
    }
    public static class NativeTheme {
        [DllImport("uxtheme.dll", CharSet=CharSet.Unicode)] static extern int SetWindowTheme(IntPtr h, string app, string id);
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int value, int size);
        public static void Apply(Control control) {
            try {
                SetWindowTheme(control.Handle, "DarkMode_Explorer", null);
                if (control is Form) {
                    int on = 1;
                    if (DwmSetWindowAttribute(control.Handle, 20, ref on, 4) != 0)
                        DwmSetWindowAttribute(control.Handle, 19, ref on, 4);
                }
            } catch (DllNotFoundException) { } catch (EntryPointNotFoundException) { }
        }
    }
    // Keep confirmation results identical to MessageBox while painting our own dialog.
    public static class GoblinMessage {
        public static DialogResult Show(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon) {
            using (Form dialog = new Form()) {
                dialog.Text = title; dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.MaximizeBox = false; dialog.MinimizeBox = false;
                dialog.BackColor = Palette.Background; dialog.ForeColor = Palette.Text;
                dialog.Font = new Font("Segoe UI", 10);
                int width = Math.Min(380, Screen.FromPoint(Cursor.Position).WorkingArea.Width - 40);
                Label text = new Label(); text.Text = message; text.AutoSize = true;
                text.MaximumSize = new Size(width - 32, 0); text.Location = new Point(16, 16);
                dialog.Controls.Add(text);
                FlowLayoutPanel actions = new FlowLayoutPanel();
                actions.Location = new Point(12, text.Bottom + 12); actions.Size = new Size(width - 24, 48);
                DialogResult[] results = buttons == MessageBoxButtons.YesNo ?
                    new DialogResult[] { DialogResult.Yes, DialogResult.No } : new DialogResult[] { DialogResult.OK };
                foreach (DialogResult result in results) {
                    Button b = new Button(); b.Text = result.ToString(); b.DialogResult = result;
                    b.Size = new Size(96, 40); b.FlatStyle = FlatStyle.Flat;
                    b.FlatAppearance.BorderColor = Palette.Line;
                    b.BackColor = Palette.Surface; b.ForeColor = Palette.Text;
                    actions.Controls.Add(b);
                    if (result == DialogResult.No || result == DialogResult.OK) { dialog.CancelButton = b; dialog.AcceptButton = b; }
                }
                dialog.Controls.Add(actions);
                dialog.ClientSize = new Size(width, Math.Min(actions.Bottom + 12, Screen.FromPoint(Cursor.Position).WorkingArea.Height - 80));
                dialog.AutoScroll = true;
                dialog.HandleCreated += delegate { NativeTheme.Apply(dialog); };
                return Form.ActiveForm == null ? dialog.ShowDialog() : dialog.ShowDialog(Form.ActiveForm);
            }
        }
    }
}
'@
}

function Set-GoblinDarkSurface {
    param([System.Windows.Forms.Control]$Control)
    if ($Control -is [System.Windows.Forms.TabPage]) { $Control.UseVisualStyleBackColor = $false }
    if ($Control -is [System.Windows.Forms.CheckBox]) { $Control.FlatStyle = 'Flat' }
    if ($Control -is [System.Windows.Forms.DataGridView]) {
        $Control.BackgroundColor = [PlexGoblin.Palette]::Panel
        $Control.ColumnHeadersDefaultCellStyle.ForeColor = [PlexGoblin.Palette]::Green
        $Control.ColumnHeadersDefaultCellStyle.SelectionBackColor = [PlexGoblin.Palette]::Surface
        $Control.ColumnHeadersDefaultCellStyle.SelectionForeColor = [PlexGoblin.Palette]::Green
        $Control.DefaultCellStyle.NullValue = ''
        foreach ($column in $Control.Columns) {
            if ($column -is [Windows.Forms.DataGridViewCheckBoxColumn]) { $column.FlatStyle = 'Flat' }
        }
    }
    elseif ($Control -is [System.Windows.Forms.ToolStrip]) {
        $Control.Renderer = New-Object System.Windows.Forms.ToolStripProfessionalRenderer((New-Object PlexGoblin.GoblinMenuColors))
        $Control.BackColor = [PlexGoblin.Palette]::Panel
        $Control.ForeColor = [PlexGoblin.Palette]::Text
        foreach ($item in $Control.Items) { $item.ForeColor = [PlexGoblin.Palette]::Text }
    }
    elseif ($Control -is [System.Windows.Forms.TextBoxBase] -or $Control -is [System.Windows.Forms.NumericUpDown]) {
        $Control.BackColor = [PlexGoblin.Palette]::Input
        $Control.ForeColor = [PlexGoblin.Palette]::Text
        if ($Control -is [System.Windows.Forms.TextBoxBase]) { $Control.BorderStyle = 'FixedSingle' }
    }
    elseif ($Control -is [System.Windows.Forms.Panel] -or $Control -is [System.Windows.Forms.TabPage] -or $Control -is [System.Windows.Forms.Form]) {
        $Control.BackColor = [PlexGoblin.Palette]::Background
        $Control.ForeColor = [PlexGoblin.Palette]::Text
    }
    # Reapply on handle recreation (DPI/theme changes), not just first launch.
    if (-not $Control.IsHandleCreated) { $Control.Add_HandleCreated({ param($sender, $args) [PlexGoblin.NativeTheme]::Apply($sender) }) }
    else { [PlexGoblin.NativeTheme]::Apply($Control) }
    foreach ($child in $Control.Controls) { Set-GoblinDarkSurface -Control $child }
}

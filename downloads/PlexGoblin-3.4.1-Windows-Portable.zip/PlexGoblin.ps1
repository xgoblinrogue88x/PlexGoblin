﻿[CmdletBinding()]
param(
    [switch]$StartHidden
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Security
[System.Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'GoblinTheme.ps1')
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$script:AppName = 'Plex Goblin'
$script:AppVersion = '3.4.1-preview'
$script:ClientIdentifier = 'plex-goblin-windows-v3'
$script:DataDirectory = Join-Path $PSScriptRoot 'Data'
$script:PreviousDataDirectory = Join-Path $env:LOCALAPPDATA 'PlexPause'
$script:PreviousLockPath = Join-Path $script:PreviousDataDirectory 'PlexPause.lock'
$script:LegacyStatePath = Join-Path $script:DataDirectory 'state.json'
$script:LegacyRecoveryDirectory = Join-Path $script:DataDirectory 'Recovery'
$script:TokenPath = Join-Path $script:DataDirectory 'token.dat'
$script:TokenTempPath = Join-Path $script:DataDirectory 'token.tmp'
$script:LogPath = Join-Path $script:DataDirectory 'PlexGoblin.log'
$script:LockPath = Join-Path $script:DataDirectory 'PlexGoblin.lock'
$script:PortableMigrationOccurred = $false
$script:PortableMigrationWarnings = @()
$script:Token = $null
$script:MachineIdentifier = $null
$script:OwnerName = $null
$script:OwnerEmail = $null
$script:Users = @()
$script:BlockedUserIds = @{}
$script:AutoAllowDeadlines = @{}
$script:RecentlyStopped = @{}
$script:Polling = $false
$script:UpdatingGrid = $false
$script:LastPollError = ''
$script:StoppedCount = 0
$script:ExitRequested = $false
$script:TrayHintShown = $false
$script:UpdatingStartupUi = $false

function Get-ActivationEventName {
    $normalizedRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\').ToLowerInvariant()
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($normalizedRoot))
        $shortHash = ([BitConverter]::ToString($hash)).Replace('-', '').Substring(0, 16)
        return "Local\PlexGoblin.Activate.$shortHash"
    }
    finally { $sha256.Dispose() }
}

$script:ActivationEventName = Get-ActivationEventName

try {
    if (-not (Test-Path -LiteralPath $script:DataDirectory)) {
        New-Item -ItemType Directory -Path $script:DataDirectory -Force | Out-Null
    }
}
catch {
    [PlexGoblin.GoblinMessage]::Show(
        "Plex Goblin could not create its Data folder beside the application.`r`n`r`nMove the PlexGoblin folder to a location your Windows account can write to, such as Documents, then try again.`r`n`r`n$($_.Exception.Message)",
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

# Windows automatically releases this single-instance lock on exit, crash,
# shutdown, or power loss.
try {
    $script:InstanceLock = [IO.File]::Open(
        $script:LockPath,
        [IO.FileMode]::OpenOrCreate,
        [IO.FileAccess]::ReadWrite,
        [IO.FileShare]::None
    )
}
catch {
    # If this exact portable copy is already running in the tray, ask it to
    # restore its existing window instead of showing a second-instance error.
    try {
        $existingActivationEvent = [Threading.EventWaitHandle]::OpenExisting($script:ActivationEventName)
        try { $existingActivationEvent.Set() | Out-Null }
        finally { $existingActivationEvent.Dispose() }
        exit 0
    }
    catch { }
    [PlexGoblin.GoblinMessage]::Show(
        "Plex Goblin could not lock its portable Data folder.`r`n`r`nAnother copy may already be running, or this application folder may not be writable. Close other copies or move the PlexGoblin folder to Documents and try again.",
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit 1
}

$script:ActivationEvent = [Threading.EventWaitHandle]::new(
    $false,
    [Threading.EventResetMode]::AutoReset,
    $script:ActivationEventName
)

function Test-PreviousPlexAppRunning {
    if (-not (Test-Path -LiteralPath $script:PreviousLockPath -PathType Leaf)) { return $false }
    $probe = $null
    try {
        $probe = [IO.File]::Open(
            $script:PreviousLockPath,
            [IO.FileMode]::Open,
            [IO.FileAccess]::Read,
            [IO.FileShare]::ReadWrite
        )
        return $false
    }
    catch { return $true }
    finally {
        if ($null -ne $probe) { $probe.Dispose() }
    }
}

if (Test-PreviousPlexAppRunning) {
    [PlexGoblin.GoblinMessage]::Show(
        'An older Plex Goblin or Plex Pause copy is still running. Close it before starting this portable version.',
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit 1
}

function Copy-PortableDataFile {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination,
        [switch]$Optional
    )
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { return }
    if (Test-Path -LiteralPath $Destination) { return }
    try {
        $destinationDirectory = Split-Path -Parent $Destination
        if (-not (Test-Path -LiteralPath $destinationDirectory -PathType Container)) {
            New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        }
        [IO.File]::Copy($Source, $Destination, $false)
        $script:PortableMigrationOccurred = $true
    }
    catch {
        if ($Optional) {
            $script:PortableMigrationWarnings += "Could not copy $([IO.Path]::GetFileName($Source)): $($_.Exception.Message)"
            return
        }
        throw "Could not copy required existing data $([IO.Path]::GetFileName($Source)) into the portable Data folder: $($_.Exception.Message)"
    }
}

function Import-PreviousPlexGoblinData {
    if (-not (Test-Path -LiteralPath $script:PreviousDataDirectory -PathType Container)) { return }

    foreach ($name in @('token.dat', 'state.json')) {
        Copy-PortableDataFile `
            -Source (Join-Path $script:PreviousDataDirectory $name) `
            -Destination (Join-Path $script:DataDirectory $name)
    }
    foreach ($name in @('PlexPause.log', 'PlexGoblin.log')) {
        Copy-PortableDataFile `
            -Source (Join-Path $script:PreviousDataDirectory $name) `
            -Destination (Join-Path $script:DataDirectory $name) `
            -Optional
    }

    $oldRecovery = Join-Path $script:PreviousDataDirectory 'Recovery'
    $newRecovery = Join-Path $script:DataDirectory 'Recovery'
    if (Test-Path -LiteralPath $oldRecovery -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $oldRecovery -Filter 'active-*.json' -File -ErrorAction SilentlyContinue)) {
            Copy-PortableDataFile -Source $file.FullName -Destination (Join-Path $newRecovery $file.Name)
        }
    }

    $oldStream = Join-Path $script:PreviousDataDirectory 'StreamGoblin'
    $newStream = Join-Path $script:DataDirectory 'StreamGoblin'
    foreach ($name in @('config.json', 'tautulli-key.dat')) {
        Copy-PortableDataFile `
            -Source (Join-Path $oldStream $name) `
            -Destination (Join-Path $newStream $name)
    }
    Copy-PortableDataFile `
        -Source (Join-Path $oldStream 'status.json') `
        -Destination (Join-Path $newStream 'status.json') `
        -Optional

    $oldLogs = Join-Path $oldStream 'Logs'
    $newLogs = Join-Path $newStream 'Logs'
    if (Test-Path -LiteralPath $oldLogs -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $oldLogs -File -ErrorAction SilentlyContinue)) {
            $isDailyLog = ($file.Name -match '^\d{2}-\d{2}-\d{4} GoblinLog\.txt$')
            $isLegacyLog = ($file.Name -eq 'legacy-stream_goblin.log')
            if (-not $isDailyLog -and -not $isLegacyLog) { continue }
            Copy-PortableDataFile -Source $file.FullName -Destination (Join-Path $newLogs $file.Name) -Optional
        }
    }
}

try { Import-PreviousPlexGoblinData }
catch {
    [PlexGoblin.GoblinMessage]::Show(
        "Plex Goblin could not safely copy the existing settings into its portable Data folder. The old files were not changed.`r`n`r`n$($_.Exception.Message)",
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

function Write-AppLog {
    param([string]$Message)
    Add-Content -LiteralPath $script:LogPath -Value ('{0:u} {1}' -f (Get-Date), $Message) -Encoding UTF8
}

if ($script:PortableMigrationOccurred) {
    Write-AppLog 'Copied existing Plex Goblin data into the portable application Data folder. Original files were left unchanged.'
}
foreach ($warning in $script:PortableMigrationWarnings) {
    Write-AppLog "Portable data migration warning: $warning"
}

$script:StreamGoblinModulePath = Join-Path $PSScriptRoot 'StreamGoblinEngine.ps1'
if (-not (Test-Path -LiteralPath $script:StreamGoblinModulePath)) {
    [PlexGoblin.GoblinMessage]::Show(
        'StreamGoblinEngine.ps1 is missing. Extract the complete Plex Goblin folder and try again.',
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
. $script:StreamGoblinModulePath

$script:StartupShortcutPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'Plex Goblin.lnk'

function Test-PlexGoblinAutostart {
    if (-not (Test-Path -LiteralPath $script:StartupShortcutPath -PathType Leaf)) { return $false }
    $shell = $null
    $shortcut = $null
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($script:StartupShortcutPath)
        $expectedScript = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'PlexGoblin.ps1'))
        $actualTarget = [IO.Path]::GetFullPath([string]$shortcut.TargetPath)
        $expectedTarget = [IO.Path]::GetFullPath((Join-Path $PSHOME 'powershell.exe'))
        return (
            $actualTarget.Equals($expectedTarget, [StringComparison]::OrdinalIgnoreCase) -and
            ([string]$shortcut.Arguments).IndexOf(('"{0}"' -f $expectedScript), [StringComparison]::OrdinalIgnoreCase) -ge 0 -and
            ([string]$shortcut.Arguments) -match '(?i)(?:^|\s)-StartHidden(?:\s|$)'
        )
    }
    catch { return $false }
    finally {
        if ($null -ne $shortcut) { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut) | Out-Null }
        if ($null -ne $shell) { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) | Out-Null }
    }
}

function Set-PlexGoblinAutostart {
    param([Parameter(Mandatory = $true)][bool]$Enabled)

    if (-not $Enabled) {
        if (Test-Path -LiteralPath $script:StartupShortcutPath -PathType Leaf) {
            [IO.File]::Delete($script:StartupShortcutPath)
        }
        return
    }

    $startupDirectory = Split-Path -Parent $script:StartupShortcutPath
    if (-not (Test-Path -LiteralPath $startupDirectory -PathType Container)) {
        throw 'The Windows Startup folder is unavailable for this account.'
    }

    $scriptPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'PlexGoblin.ps1'))
    $powerShellPath = [IO.Path]::GetFullPath((Join-Path $PSHOME 'powershell.exe'))
    $shell = $null
    $shortcut = $null
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($script:StartupShortcutPath)
        $shortcut.TargetPath = $powerShellPath
        $shortcut.Arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}" -StartHidden' -f $scriptPath
        $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.IconLocation = (Join-Path $PSScriptRoot 'PlexGoblin.ico') + ',0'
        $shortcut.Description = 'Start Plex Goblin silently in the notification area.'
        $shortcut.WindowStyle = 7
        $shortcut.Save()
    }
    finally {
        if ($null -ne $shortcut) { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut) | Out-Null }
        if ($null -ne $shell) { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) | Out-Null }
    }

    if (-not (Test-PlexGoblinAutostart)) {
        if (Test-Path -LiteralPath $script:StartupShortcutPath -PathType Leaf) {
            [IO.File]::Delete($script:StartupShortcutPath)
        }
        throw 'Windows created the startup shortcut, but Plex Goblin could not validate it.'
    }
}

function Get-XmlAttribute {
    param(
        [Parameter(Mandatory = $true)]$Node,
        [Parameter(Mandatory = $true)][string]$Name,
        [string]$Default = ''
    )
    if ($null -eq $Node -or $null -eq $Node.Attributes) { return $Default }
    $attribute = $Node.Attributes[$Name]
    if ($null -eq $attribute) { return $Default }
    return [string]$attribute.Value
}

function Convert-ToBoolean {
    param([string]$Value)
    return ($Value -eq '1' -or $Value -eq 'true')
}

function Test-LegacyPersistentPause {
    # Version 1 stored persistent restriction-recovery records. Plex Goblin
    # never alters them. An unreadable record is treated conservatively as active.
    $found = $false
    $statePaths = @(
        $script:LegacyStatePath,
        (Join-Path $script:PreviousDataDirectory 'state.json')
    ) | Sort-Object -Unique
    foreach ($statePath in $statePaths) {
        if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { continue }
        try {
            $legacyState = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($null -ne $legacyState.paused -and @($legacyState.paused).Count -gt 0) { $found = $true }
        }
        catch { $found = $true }
    }

    $recoveryDirectories = @(
        $script:LegacyRecoveryDirectory,
        (Join-Path $script:PreviousDataDirectory 'Recovery')
    ) | Sort-Object -Unique
    foreach ($recoveryDirectory in $recoveryDirectories) {
        if (Test-Path -LiteralPath $recoveryDirectory -PathType Container) {
            if (@(Get-ChildItem -LiteralPath $recoveryDirectory -Filter 'active-*.json' -File -ErrorAction SilentlyContinue).Count -gt 0) {
                $found = $true
            }
        }
    }
    return $found
}

if (Test-LegacyPersistentPause) {
    [PlexGoblin.GoblinMessage]::Show(
        "Plex Goblin found an unfinished pause created by version 1.`r`n`r`nFor safety, version 3 will not start or alter that data. Restore those users with version 1 or in Plex Web first, then start Plex Goblin again.`r`n`r`nNothing was changed by this launch.",
        $script:AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    Write-AppLog 'Startup stopped because active or unreadable version 1 recovery data exists.'
    exit 1
}

function Protect-Token {
    param([Parameter(Mandatory = $true)][string]$Token)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Token)
    $protected = [Security.Cryptography.ProtectedData]::Protect(
        $bytes,
        $null,
        [Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    [IO.File]::WriteAllBytes($script:TokenTempPath, $protected)
    Complete-GoblinAtomicWrite -TempPath $script:TokenTempPath -Path $script:TokenPath
}

function Read-ProtectedToken {
    if (-not (Test-Path -LiteralPath $script:TokenPath)) { return $null }
    try {
        $protected = [IO.File]::ReadAllBytes($script:TokenPath)
        $bytes = [Security.Cryptography.ProtectedData]::Unprotect(
            $protected,
            $null,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        return [Text.Encoding]::UTF8.GetString($bytes)
    }
    catch {
        Write-AppLog "Could not read the saved token: $($_.Exception.Message)"
        return $null
    }
}

function Get-RegistrySettings {
    $paths = @(
        'HKCU:\Software\Plex, Inc.\Plex Media Server',
        'HKCU:\Software\WOW6432Node\Plex, Inc.\Plex Media Server'
    )
    foreach ($path in $paths) {
        try {
            $settings = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
            if ($settings.PlexOnlineToken) {
                return [PSCustomObject]@{
                    Token = [string]$settings.PlexOnlineToken
                    MachineIdentifier = [string]$settings.MachineIdentifier
                }
            }
        }
        catch { }
    }
    return $null
}

function Show-TokenDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Connect Plex Goblin'
    $dialog.StartPosition = 'CenterScreen'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(560, 220)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Plex could not be read from this Windows account.'
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(18, 18)
    $dialog.Controls.Add($title)

    $help = New-Object System.Windows.Forms.Label
    $help.Text = 'Paste the Plex token belonging to the server owner. It is encrypted for this Windows user. See README.txt for instructions.'
    $help.Location = New-Object System.Drawing.Point(18, 55)
    $help.Size = New-Object System.Drawing.Size(520, 45)
    $dialog.Controls.Add($help)

    $tokenBox = New-Object System.Windows.Forms.TextBox
    $tokenBox.Location = New-Object System.Drawing.Point(20, 108)
    $tokenBox.Size = New-Object System.Drawing.Size(515, 25)
    $tokenBox.UseSystemPasswordChar = $true
    $dialog.Controls.Add($tokenBox)

    $showCheck = New-Object System.Windows.Forms.CheckBox
    $showCheck.Text = 'Show token'
    $showCheck.Location = New-Object System.Drawing.Point(20, 142)
    $showCheck.AutoSize = $true
    $showCheck.Add_CheckedChanged({ $tokenBox.UseSystemPasswordChar = -not $showCheck.Checked })
    $dialog.Controls.Add($showCheck)

    $connectButton = New-Object System.Windows.Forms.Button
    $connectButton.Text = 'Connect'
    $connectButton.Location = New-Object System.Drawing.Point(350, 170)
    $connectButton.Size = New-Object System.Drawing.Size(88, 30)
    $connectButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dialog.AcceptButton = $connectButton
    $dialog.Controls.Add($connectButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = 'Cancel'
    $cancelButton.Location = New-Object System.Drawing.Point(447, 170)
    $cancelButton.Size = New-Object System.Drawing.Size(88, 30)
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dialog.CancelButton = $cancelButton
    $dialog.Controls.Add($cancelButton)

    Set-GoblinCompactDialog -Dialog $dialog -Fields @($title, $help, $tokenBox, $showCheck) -Buttons @($connectButton, $cancelButton)
    Set-GoblinDarkSurface -Control $dialog
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    return $tokenBox.Text.Trim()
}

function Get-PlexHeaders {
    return @{
        'X-Plex-Token' = $script:Token
        'X-Plex-Client-Identifier' = $script:ClientIdentifier
        'X-Plex-Product' = $script:AppName
        'X-Plex-Version' = $script:AppVersion
        'Accept' = 'application/xml'
    }
}

function Invoke-PlexRequest {
    param([Parameter(Mandatory = $true)][string]$Uri)

    $parsedUri = [Uri]$Uri
    $isLocalRead = ($parsedUri.Scheme -eq 'http' -and
        $parsedUri.Host -eq '127.0.0.1' -and
        $parsedUri.Port -eq 32400 -and
        ($parsedUri.AbsolutePath -eq '/' -or $parsedUri.AbsolutePath -eq '/accounts' -or
            $parsedUri.AbsolutePath -eq '/status/sessions'))
    $isLocalSessionStop = ($parsedUri.Scheme -eq 'http' -and
        $parsedUri.Host -eq '127.0.0.1' -and
        $parsedUri.Port -eq 32400 -and
        $parsedUri.AbsolutePath -eq '/status/sessions/terminate')
    $isAccountRead = ($parsedUri.Scheme -eq 'https' -and
        $parsedUri.Host -eq 'plex.tv' -and
        ($parsedUri.AbsolutePath -eq '/api/v2/user' -or $parsedUri.AbsolutePath -eq '/api/users/'))
    $expectedShareDetailsPath = '/api/servers/{0}/shared_servers' -f $script:MachineIdentifier
    $isShareDetailsRead = ($parsedUri.Scheme -eq 'https' -and
        $parsedUri.Host -eq 'plex.tv' -and
        -not [string]::IsNullOrWhiteSpace($script:MachineIdentifier) -and
        $parsedUri.AbsolutePath -eq $expectedShareDetailsPath -and
        [string]::IsNullOrWhiteSpace($parsedUri.Query))

    if (-not ($isLocalRead -or $isLocalSessionStop -or $isAccountRead -or $isShareDetailsRead)) {
        throw "Blocked an unexpected request: GET $($parsedUri.Scheme)://$($parsedUri.Host)$($parsedUri.AbsolutePath)"
    }
    if ($isLocalSessionStop -and $parsedUri.Query.TrimStart('?') -notmatch '^sessionId=[^&]+&reason=[^&]*$') {
        throw 'Blocked a malformed session-termination request.'
    }

    return Invoke-WebRequest -Uri $Uri -Method Get -Headers (Get-PlexHeaders) `
        -UseBasicParsing -TimeoutSec 12 -MaximumRedirection 0
}

function Get-LocalServerIdentity {
    try {
        [xml]$xml = (Invoke-PlexRequest -Uri 'http://127.0.0.1:32400/').Content
        $rootNode = $xml.DocumentElement
        return [PSCustomObject]@{
            MachineIdentifier = Get-XmlAttribute -Node $rootNode -Name 'machineIdentifier'
            OwnerUsername = Get-XmlAttribute -Node $rootNode -Name 'myPlexUsername'
        }
    }
    catch { return $null }
}

function Set-OwnerFromAccountResponse {
    param([Parameter(Mandatory = $true)]$Response)
    [xml]$accountXml = $Response.Content
    $accountNode = $accountXml.DocumentElement
    $script:OwnerName = Get-XmlAttribute -Node $accountNode -Name 'username'
    $script:OwnerEmail = Get-XmlAttribute -Node $accountNode -Name 'email'
    if ([string]::IsNullOrWhiteSpace($script:OwnerName)) {
        $script:OwnerName = Get-XmlAttribute -Node $accountNode -Name 'title' -Default 'Server owner'
    }
}

function Initialize-PlexConnection {
    $registry = Get-RegistrySettings
    $registryMachineIdentifier = ''
    if ($null -ne $registry) { $registryMachineIdentifier = [string]$registry.MachineIdentifier }

    $savedToken = Read-ProtectedToken
    if (-not [string]::IsNullOrWhiteSpace($savedToken)) { $script:Token = $savedToken }
    elseif ($null -ne $registry) { $script:Token = $registry.Token }

    if ([string]::IsNullOrWhiteSpace($script:Token)) {
        $script:Token = Show-TokenDialog
        if ([string]::IsNullOrWhiteSpace($script:Token)) { return $false }
        Protect-Token -Token $script:Token
    }

    try {
        Set-OwnerFromAccountResponse -Response (Invoke-PlexRequest -Uri 'https://plex.tv/api/v2/user')
    }
    catch {
        Write-AppLog "Automatic owner-token validation failed: $($_.Exception.Message)"
        $answer = [PlexGoblin.GoblinMessage]::Show(
            "Plex could not verify the automatically discovered token.`r`n`r`nWould you like to paste a current owner token instead?",
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
        $script:Token = Show-TokenDialog
        if ([string]::IsNullOrWhiteSpace($script:Token)) { return $false }
        try {
            Set-OwnerFromAccountResponse -Response (Invoke-PlexRequest -Uri 'https://plex.tv/api/v2/user')
            Protect-Token -Token $script:Token
        }
        catch {
            [PlexGoblin.GoblinMessage]::Show(
                "Plex rejected the token you entered. Nothing was changed.`r`n`r`n$($_.Exception.Message)",
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            return $false
        }
    }

    $localIdentity = Get-LocalServerIdentity
    if ($null -eq $localIdentity -or [string]::IsNullOrWhiteSpace($localIdentity.MachineIdentifier)) {
        [PlexGoblin.GoblinMessage]::Show(
            'The local Plex Media Server was not found. Run this on the Windows PC hosting Plex while Plex Media Server is running.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return $false
    }
    if (-not [string]::IsNullOrWhiteSpace($registryMachineIdentifier) -and
        $registryMachineIdentifier -ne $localIdentity.MachineIdentifier) {
        # Plex can leave an older machine ID in this Windows user's registry,
        # especially after a server reinstall, migration, or service-account
        # change. The authenticated running server is authoritative. Continue
        # only because the owner-account comparison below still protects us.
        Write-AppLog 'The registry server ID was stale; using the authenticated running local server ID instead.'
    }
    $script:MachineIdentifier = [string]$localIdentity.MachineIdentifier
    if ($script:MachineIdentifier.Length -gt 200 -or $script:MachineIdentifier -notmatch '^[A-Za-z0-9._-]+$') {
        [PlexGoblin.GoblinMessage]::Show(
            'The local Plex server returned an invalid machine identifier. Nothing was changed.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return $false
    }

    if (-not [string]::IsNullOrWhiteSpace($localIdentity.OwnerUsername) -and
        -not [string]::IsNullOrWhiteSpace($script:OwnerName) -and
        $localIdentity.OwnerUsername -ine $script:OwnerName -and
        $localIdentity.OwnerUsername -ine $script:OwnerEmail) {
        [PlexGoblin.GoblinMessage]::Show(
            'The Plex token belongs to a different account than the running local server. Nothing was changed.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return $false
    }
    return $true
}

function Get-SharedUsers {
    [xml]$accountsXml = (Invoke-PlexRequest -Uri 'http://127.0.0.1:32400/accounts').Content
    $localAccounts = @()
    foreach ($accountNode in @($accountsXml.SelectNodes('/MediaContainer/Account'))) {
        $localId = Get-XmlAttribute -Node $accountNode -Name 'id'
        $localName = Get-XmlAttribute -Node $accountNode -Name 'name'
        if ($localId -notmatch '^\d+$' -or [string]::IsNullOrWhiteSpace($localName)) { continue }
        # Plex reserves local account ID 1 for the server owner.
        if ($localId -eq '1') { continue }
        $localAccounts += [PSCustomObject]@{ Id = $localId; Name = $localName }
    }

    [xml]$xml = (Invoke-PlexRequest -Uri 'https://plex.tv/api/users/').Content
    $shareDetailsUri = 'https://plex.tv/api/servers/{0}/shared_servers' -f $script:MachineIdentifier
    [xml]$shareDetailsXml = (Invoke-PlexRequest -Uri $shareDetailsUri).Content
    $shareDetailNodes = @($shareDetailsXml.SelectNodes('//SharedServer'))
    $users = @()
    foreach ($userNode in @($xml.SelectNodes('/MediaContainer/User'))) {
        $matchingServer = $null
        foreach ($serverNode in @($userNode.SelectNodes('Server'))) {
            if ((Get-XmlAttribute -Node $serverNode -Name 'machineIdentifier') -eq $script:MachineIdentifier) {
                $matchingServer = $serverNode
                break
            }
        }
        if ($null -eq $matchingServer) { continue }

        $cloudUserId = Get-XmlAttribute -Node $userNode -Name 'id'
        $serverShareId = Get-XmlAttribute -Node $matchingServer -Name 'id'
        $matchingShareDetails = $null
        foreach ($shareNode in $shareDetailNodes) {
            $detailUserId = Get-XmlAttribute -Node $shareNode -Name 'userID'
            $detailShareId = Get-XmlAttribute -Node $shareNode -Name 'id'
            if ((-not [string]::IsNullOrWhiteSpace($cloudUserId) -and $detailUserId -eq $cloudUserId) -or
                (-not [string]::IsNullOrWhiteSpace($serverShareId) -and $detailShareId -eq $serverShareId)) {
                $matchingShareDetails = $shareNode
                break
            }
        }

        $libraryNames = @()
        $allLibraries = Convert-ToBoolean (Get-XmlAttribute -Node $matchingServer -Name 'allLibraries')
        if ($null -ne $matchingShareDetails) {
            $allLibraries = $allLibraries -or (Convert-ToBoolean (Get-XmlAttribute -Node $matchingShareDetails -Name 'allLibraries'))
        }
        if ($allLibraries) {
            $libraryNames = @('All libraries')
        }
        else {
            # /api/users/ does not include individually selected sections.
            # Plex exposes them through this share-details response instead.
            $sectionSource = if ($null -ne $matchingShareDetails) { $matchingShareDetails } else { $matchingServer }
            foreach ($section in @($sectionSource.SelectNodes('.//Section'))) {
                if (Convert-ToBoolean (Get-XmlAttribute -Node $section -Name 'shared' -Default '0')) {
                    $name = Get-XmlAttribute -Node $section -Name 'title'
                    if (-not [string]::IsNullOrWhiteSpace($name)) { $libraryNames += $name }
                }
            }
            $libraryNames = @($libraryNames | Sort-Object -Unique)
            if ($libraryNames.Count -eq 0) { $libraryNames = @('(none reported by Plex)') }
        }

        $username = Get-XmlAttribute -Node $userNode -Name 'username'
        $title = Get-XmlAttribute -Node $userNode -Name 'title'
        $email = Get-XmlAttribute -Node $userNode -Name 'email'
        if ([string]::IsNullOrWhiteSpace($username)) { $username = $title }

        $aliases = @($username, $title, $email) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
        $localMatches = @($localAccounts | Where-Object {
            $localAccountName = $_.Name
            @($aliases | Where-Object { $_ -ieq $localAccountName }).Count -gt 0
        })
        if ($localMatches.Count -ne 1) {
            Write-AppLog "Ignored shared account because it could not be mapped unambiguously to a local Plex account: $username"
            continue
        }

        $user = [PSCustomObject]@{
            Id = [string]$localMatches[0].Id
            Username = $username
            Title = $title
            Email = $email
            Libraries = ($libraryNames -join ', ')
        }
        $users += $user
    }
    return @($users | Sort-Object Username)
}

function Get-ActiveSessions {
    [xml]$xml = (Invoke-PlexRequest -Uri 'http://127.0.0.1:32400/status/sessions').Content
    $sessions = @()
    foreach ($mediaNode in @($xml.DocumentElement.ChildNodes)) {
        if ($null -eq $mediaNode -or $mediaNode.NodeType -ne [Xml.XmlNodeType]::Element) { continue }
        $userNode = $mediaNode.SelectSingleNode('User')
        $sessionNode = $mediaNode.SelectSingleNode('Session')
        if ($null -eq $userNode -or $null -eq $sessionNode) { continue }
        $sessions += [PSCustomObject]@{
            UserId = Get-XmlAttribute -Node $userNode -Name 'id'
            UserTitle = Get-XmlAttribute -Node $userNode -Name 'title'
            SessionId = Get-XmlAttribute -Node $sessionNode -Name 'id'
            MediaTitle = Get-XmlAttribute -Node $mediaNode -Name 'grandparentTitle'
            ItemTitle = Get-XmlAttribute -Node $mediaNode -Name 'title'
        }
    }
    return $sessions
}

function Stop-PlexSession {
    param([Parameter(Mandatory = $true)][string]$SessionId)
    if ([string]::IsNullOrWhiteSpace($SessionId) -or $SessionId.Length -gt 200 -or
        $SessionId -notmatch '^[A-Za-z0-9._:-]+$') {
        throw 'Plex returned an invalid session ID. The session was not touched.'
    }
    $reason = [Uri]::EscapeDataString('Server temporarily unavailable.')
    $uri = 'http://127.0.0.1:32400/status/sessions/terminate?sessionId={0}&reason={1}' -f [Uri]::EscapeDataString($SessionId), $reason
    Invoke-PlexRequest -Uri $uri | Out-Null
}

if (-not (Initialize-PlexConnection)) { exit 1 }

# Dark palette. These values affect presentation only; enforcement behavior and
# the runtime-only blocklist remain unchanged.
$theme = @{
    Window = [Drawing.ColorTranslator]::FromHtml('#0a1117')
    Surface = [Drawing.ColorTranslator]::FromHtml('#131d27')
    AlternateRow = [Drawing.ColorTranslator]::FromHtml('#1a2530')
    Header = [Drawing.ColorTranslator]::FromHtml('#1a2530')
    Border = [Drawing.ColorTranslator]::FromHtml('#31404e')
    Text = [Drawing.ColorTranslator]::FromHtml('#e9f2f4')
    MutedText = [Drawing.ColorTranslator]::FromHtml('#9eb0bd')
    Selection = [Drawing.ColorTranslator]::FromHtml('#47315f')
    Button = [Drawing.ColorTranslator]::FromHtml('#1a2530')
    ButtonHover = [Drawing.ColorTranslator]::FromHtml('#2c4051')
    Success = [Drawing.ColorTranslator]::FromHtml('#1d7939')
    SuccessHover = [Drawing.ColorTranslator]::FromHtml('#26934b')
    Owner = [Drawing.ColorTranslator]::FromHtml('#71f28b')
    Blocked = [Drawing.ColorTranslator]::FromHtml('#4a2f30')
    Accent = [Drawing.ColorTranslator]::FromHtml('#cc75ff')
    Primary = [Drawing.ColorTranslator]::FromHtml('#61228b')
    PrimaryHover = [Drawing.ColorTranslator]::FromHtml('#8229b2')
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "$($script:AppName) $($script:AppVersion)"
$form.StartPosition = 'CenterScreen'
$form.MinimumSize = New-Object System.Drawing.Size(420, 560)
$form.AutoScaleMode = 'Font'
$workArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Size = New-Object System.Drawing.Size(([Math]::Min(1000, $workArea.Width)), ([Math]::Min(740, $workArea.Height)))
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.BackColor = $theme.Window
$form.ForeColor = $theme.Text
if ($StartHidden) {
    # Keep an autostart launch from flashing on the taskbar before Shown fires.
    $form.ShowInTaskbar = $false
    $form.Opacity = 0
}
$iconPath = Join-Path $PSScriptRoot 'PlexGoblin.ico'
if (Test-Path -LiteralPath $iconPath) {
    $form.Icon = New-Object System.Drawing.Icon($iconPath)
}

$tabControl = New-Object PlexGoblin.GoblinTabs
$tabControl.Dock = 'Fill'
$tabControl.DrawMode = 'OwnerDrawFixed'
$tabControl.SizeMode = 'Fixed'
$tabControl.Multiline = $true
$tabControl.ItemSize = New-Object System.Drawing.Size(190, 40)
$pauseTab = New-Object System.Windows.Forms.TabPage
$pauseTab.Text = 'User Access + Timers'
$pauseTab.BackColor = $theme.Window
$pauseTab.ForeColor = $theme.Text
$streamGoblinTab = New-Object System.Windows.Forms.TabPage
$streamGoblinTab.Text = 'Stream + Monitor Goblin'
$streamGoblinTab.BackColor = $theme.Window
$streamGoblinTab.ForeColor = $theme.Text
$tabControl.TabPages.Add($pauseTab) | Out-Null
$tabControl.TabPages.Add($streamGoblinTab) | Out-Null

# A read-only reading page; wrapping tabs keep the third page reachable on phones.
$rulesTab = New-Object System.Windows.Forms.TabPage
$rulesTab.Text = 'Rules for the Revolution'
$rulesTab.UseVisualStyleBackColor = $false
$rulesTab.BackColor = $theme.Window
$tabControl.TabPages.Add($rulesTab) | Out-Null
$rulesPanel = New-Object System.Windows.Forms.Panel
$rulesPanel.Dock = 'Fill'
$rulesPanel.AutoScroll = $true
$rulesPanel.BackColor = $theme.Window
$rulesTitle = New-Object System.Windows.Forms.Label
$rulesTitle.Text = 'Rules for the Revolution'
$rulesTitle.Font = New-Object Drawing.Font('Segoe UI', 14, [Drawing.FontStyle]::Bold)
$rulesTitle.ForeColor = [Drawing.ColorTranslator]::FromHtml('#ffc777')
$rulesTitle.AutoSize = $true
$rulesTitle.Location = New-Object Drawing.Point(16, 16)
$rulesText = New-Object System.Windows.Forms.Label
$rulesText.Font = New-Object Drawing.Font('Segoe UI', 11)
$rulesText.ForeColor = [Drawing.ColorTranslator]::FromHtml('#ffc777')
$rulesText.AutoSize = $true
$rulesText.Location = New-Object Drawing.Point(16, 60)
$rulesText.Text = @'
Rule #1: A good guerrilla stays hidden.

Rule #2: A good guerrilla masters their environment.

Rule #3: Fucked-up situations call for fucked-up solutions.

Rule #4: Always bring a friend.

Rule #8: A guerrilla knows when to wait.

Rule #9: Use the right tool for the job.

Rule #10: Shut the fuck up.

Rule #11: Resolver means causing chaos with everything you've got.

Rule #16: A guerrilla's revolution never ends.

Rule #20: Once a guerrilla, always a guerrilla.

Rule #23: If you can eliminate the tyrant, take the opportunity.

Rule #26: Your enemy has the same right to destroy you that you have to destroy them.

Rule #46: Attack from the shadows.

Rule #48: Only take what you can defend.

Rule #73: Revolutions are won by the feared, not the fearless.

Rule #83: Every guerrilla leads their own revolution.
'@
$rulesPanel.Controls.Add($rulesTitle)
$rulesPanel.Controls.Add($rulesText)
$rulesTab.Controls.Add($rulesPanel)
$rulesPanel.Add_Resize({
    $readingWidth = [Math]::Max(120, $rulesPanel.ClientSize.Width - 48)
    $rulesTitle.MaximumSize = New-Object Drawing.Size($readingWidth, 0)
    $rulesText.MaximumSize = New-Object Drawing.Size($readingWidth, 0)
    $rulesText.Top = $rulesTitle.Bottom + 20
})

$tabControl.Add_DrawItem({
    param($sender, $eventArgs)
    $selected = ($eventArgs.Index -eq $sender.SelectedIndex)
    $backColor = if ($selected) { $theme.Selection } else { $theme.Header }
    $brush = New-Object Drawing.SolidBrush($backColor)
    try {
        $eventArgs.Graphics.FillRectangle($brush, $eventArgs.Bounds)
        [System.Windows.Forms.TextRenderer]::DrawText(
            $eventArgs.Graphics,
            $sender.TabPages[$eventArgs.Index].Text,
            $sender.Font,
            $eventArgs.Bounds,
            $theme.Text,
            [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter
        )
    }
    finally { $brush.Dispose() }
})
$form.Controls.Add($tabControl)

$header = New-Object System.Windows.Forms.Label
$header.Text = 'Block playback only while Plex Goblin is open.'
$header.ForeColor = $theme.Owner
$header.Font = New-Object System.Drawing.Font('Segoe UI', 14, [Drawing.FontStyle]::Bold)
$header.AutoSize = $true
$header.Location = New-Object System.Drawing.Point(18, 16)
$pauseTab.Controls.Add($header)

$ownerLabel = New-Object System.Windows.Forms.Label
$ownerLabel.Text = "Owner always protected: $($script:OwnerName)"
$ownerLabel.AutoSize = $true
$ownerLabel.ForeColor = $theme.Owner
$ownerLabel.Location = New-Object System.Drawing.Point(21, 50)
$pauseTab.Controls.Add($ownerLabel)

$startupCheck = New-Object System.Windows.Forms.CheckBox
$startupCheck.Text = 'Start with Windows (silent to tray)'
$startupCheck.AutoSize = $true
$startupCheck.Location = New-Object System.Drawing.Point(820, 48)
$startupCheck.ForeColor = $theme.Text
$startupCheck.BackColor = $theme.Window
$startupCheck.Checked = Test-PlexGoblinAutostart
$pauseTab.Controls.Add($startupCheck)

$explanation = New-Object System.Windows.Forms.Label
$explanation.Text = 'Check an account to block it, or use Timed Block to block it now and automatically allow it later. Access blocks exist only in memory and end when Plex Goblin exits.'
$explanation.Location = New-Object System.Drawing.Point(21, 74)
$explanation.Size = New-Object System.Drawing.Size(1020, 38)
$pauseTab.Controls.Add($explanation)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(22, 112)
$grid.Size = New-Object System.Drawing.Size(1020, 395)
$grid.Anchor = 'Top,Left'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.AutoGenerateColumns = $false
$grid.BackgroundColor = $theme.Window
$grid.BorderStyle = 'FixedSingle'
$grid.GridColor = $theme.Border
$grid.MultiSelect = $false
$grid.ReadOnly = $false
$grid.RowHeadersVisible = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersBorderStyle = 'Single'
$grid.ColumnHeadersDefaultCellStyle.BackColor = $theme.Header
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $theme.Text
$grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = $theme.Header
$grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = $theme.Text
$grid.DefaultCellStyle.BackColor = $theme.Surface
$grid.DefaultCellStyle.ForeColor = $theme.Text
$grid.DefaultCellStyle.SelectionBackColor = $theme.Selection
$grid.DefaultCellStyle.SelectionForeColor = $theme.Text
$grid.AlternatingRowsDefaultCellStyle.BackColor = $theme.AlternateRow
$grid.AlternatingRowsDefaultCellStyle.ForeColor = $theme.Text

function Add-GridColumn {
    param([string]$Name, [string]$Header, [int]$Width, [bool]$CheckBox, [bool]$Fill)
    if ($CheckBox) { $column = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn }
    else { $column = New-Object System.Windows.Forms.DataGridViewTextBoxColumn }
    $column.Name = $Name
    $column.HeaderText = $Header
    $column.Width = $Width
    $column.ReadOnly = -not $CheckBox
    if ($Fill) { $column.AutoSizeMode = 'Fill' }
    $grid.Columns.Add($column) | Out-Null
}
Add-GridColumn -Name 'Blocked' -Header 'Block' -Width 55 -CheckBox $true -Fill $false
Add-GridColumn -Name 'Status' -Header 'While open' -Width 85 -CheckBox $false -Fill $false
Add-GridColumn -Name 'Timer' -Header 'Auto-allow timer' -Width 145 -CheckBox $false -Fill $false
Add-GridColumn -Name 'Username' -Header 'Plex user' -Width 150 -CheckBox $false -Fill $false
Add-GridColumn -Name 'Email' -Header 'Email' -Width 215 -CheckBox $false -Fill $false
Add-GridColumn -Name 'Libraries' -Header 'Shared libraries' -Width 200 -CheckBox $false -Fill $true
Add-GridColumn -Name 'UserId' -Header 'User ID' -Width 20 -CheckBox $false -Fill $false
$grid.Columns['UserId'].Visible = $false
$pauseTab.Controls.Add($grid)

function New-AppButton {
    param([string]$Text, [int]$X, [int]$Width)
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Location = New-Object System.Drawing.Point($X, 520)
    $button.Size = New-Object System.Drawing.Size($Width, 31)
    $button.Anchor = 'Top,Left'
    $button.BackColor = $theme.Button
    $button.ForeColor = $theme.Text
    $button.FlatStyle = 'Flat'
    $button.FlatAppearance.BorderColor = $theme.Border
    $button.FlatAppearance.MouseOverBackColor = $theme.ButtonHover
    $button.FlatAppearance.MouseDownBackColor = $theme.Selection
    $button.UseVisualStyleBackColor = $false
    $pauseTab.Controls.Add($button)
    return $button
}
$blockAllButton = New-AppButton -Text 'Block All' -X 22 -Width 90
$allowAllButton = New-AppButton -Text 'Allow All' -X 120 -Width 90
$refreshButton = New-AppButton -Text 'Refresh Users' -X 218 -Width 110
$timedBlockButton = New-AppButton -Text 'Timed Block...' -X 336 -Width 120
$closeButton = New-AppButton -Text 'Exit and Allow Everyone' -X 844 -Width 198
$timedBlockButton.BackColor = $theme.Primary
$timedBlockButton.FlatAppearance.BorderColor = $theme.Accent
$timedBlockButton.FlatAppearance.MouseOverBackColor = $theme.PrimaryHover
$closeButton.BackColor = $theme.Success
$closeButton.FlatAppearance.MouseOverBackColor = $theme.SuccessHover

$note = New-Object System.Windows.Forms.Label
$note.Text = 'Select a row, then click Timed Block. Unchecking it allows the user early and cancels its timer. Exit Plex Goblin from the green button or tray menu to allow everyone.'
$note.Location = New-Object System.Drawing.Point(22, 563)
$note.Size = New-Object System.Drawing.Size(1020, 38)
$note.Anchor = 'Top,Left'
$note.ForeColor = $theme.MutedText
$pauseTab.Controls.Add($note)

$activity = New-Object System.Windows.Forms.Label
$activity.Text = 'No sessions stopped during this run.'
$activity.Location = New-Object System.Drawing.Point(22, 608)
$activity.Size = New-Object System.Drawing.Size(1020, 28)
$activity.Anchor = 'Top,Left'
$activity.ForeColor = $theme.MutedText
$pauseTab.Controls.Add($activity)

# Docked rows keep the grid flexible and the action buttons reachable.
$script:GoblinUiTips = New-Object System.Windows.Forms.ToolTip
$script:GoblinUiTips.BackColor = $theme.Surface
$script:GoblinUiTips.ForeColor = $theme.Text
$accessLayout = New-GoblinLayout -Rows @('Auto', 'Auto', 'Auto', 'Fill', 'Auto', 'Auto', 'Auto', 'Auto')
$accessLayout.Padding = New-Object System.Windows.Forms.Padding(12)
$header.Font = New-Object System.Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$header.AutoSize = $true
$ownerLabel.AutoEllipsis = $true
$ownerLabel.AutoSize = $false
$ownerLabel.Height = 26
$explanation.Text = 'Check a user to block playback. Timed Block allows them again automatically.'
$explanation.AutoSize = $true
$explanation.ForeColor = $theme.MutedText
$accessToolbar = New-GoblinFlow
foreach ($button in @($blockAllButton, $allowAllButton, $refreshButton, $timedBlockButton, $closeButton)) {
    $button.Height = 40
    $button.AutoSize = $true
    $button.AutoSizeMode = 'GrowAndShrink'
    $button.MinimumSize = New-Object System.Drawing.Size(0, 40)
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 3, 6, 3)
    $accessToolbar.Controls.Add($button)
}
$startupCheck.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 4)
$note.Text = 'Select a user for Timed Block. Uncheck to allow early. X hides to tray; Exit allows everyone.'
$note.AutoSize = $true
$activity.AutoSize = $true
$accountDetails = New-Object System.Windows.Forms.Label
$accountDetails.AutoSize = $false
$accountDetails.AutoEllipsis = $true
$accountDetails.Height = 38
$accountDetails.ForeColor = $theme.MutedText
$accountDetails.Text = 'Select a user to see account and library details.'
$grid.RowTemplate.Height = 36
$grid.ColumnHeadersHeight = 36
$grid.Columns['Blocked'].Width = 48
$grid.Columns['Status'].Width = 78
$grid.Columns['Timer'].Width = 100
$grid.Columns['Timer'].HeaderText = 'Auto-allow'
$grid.Columns['Username'].AutoSizeMode = 'Fill'
$grid.Columns['Username'].MinimumWidth = 95
$grid.Columns['Libraries'].AutoSizeMode = 'None'
$grid.Columns['Username'].DisplayIndex = 1
$grid.Columns['Email'].Visible = $false
$grid.Columns['Libraries'].Visible = $false
$grid.Add_SelectionChanged({
    if ($grid.SelectedRows.Count -gt 0) {
        $row = $grid.SelectedRows[0]
        $accountDetails.Text = ('{0} | {1} | Libraries: {2}' -f $row.Cells['Username'].Value, $row.Cells['Email'].Value, $row.Cells['Libraries'].Value)
        $script:GoblinUiTips.SetToolTip($accountDetails, $accountDetails.Text)
    }
})
$script:GoblinUiTips.SetToolTip($header, ($explanation.Text + ' ' + $note.Text))
$accessLayout.Controls.Add($header, 0, 0)
$accessLayout.Controls.Add($ownerLabel, 0, 1)
$accessLayout.Controls.Add($explanation, 0, 2)
$accessLayout.Controls.Add($grid, 0, 3)
$accessLayout.Controls.Add($accountDetails, 0, 4)
$accessLayout.Controls.Add($accessToolbar, 0, 5)
$accessLayout.Controls.Add($note, 0, 6)
$accessFooter = New-GoblinFlow
$accessFooter.Controls.Add($startupCheck)
$accessFooter.Controls.Add($activity)
$accessLayout.Controls.Add($accessFooter, 0, 7)
foreach ($control in @($header, $ownerLabel, $explanation, $grid, $accountDetails, $accessToolbar, $note, $accessFooter)) { $control.Dock = 'Fill' }
$pauseTab.Controls.Add($accessLayout)
function Update-PauseTabLayout {
    # Compare logical width so Windows text scaling keeps compact mode usable.
    $wide = ($pauseTab.ClientSize.Width / ($form.Font.Size / 10.0)) -ge 800
    $explanation.Visible = $wide
    $note.Visible = $wide
    $activity.Visible = $wide
    $grid.Columns['Email'].Visible = $wide
    $grid.Columns['Libraries'].Visible = $wide
}
$pauseTab.Add_Resize({ Update-PauseTabLayout })

$statusBar = New-Object System.Windows.Forms.StatusStrip
$statusText = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusText.Text = 'Starting...'
$statusText.Spring = $true
$statusText.TextAlign = 'MiddleLeft'
$statusBar.Items.Add($statusText) | Out-Null
$statusBar.BackColor = $theme.Header
$statusBar.ForeColor = $theme.Text
$statusBar.SizingGrip = $false
$statusText.ForeColor = $theme.Text
$form.Controls.Add($statusBar)
$tabControl.BringToFront()

$trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
$trayMenu.BackColor = $theme.Surface
$trayMenu.ForeColor = $theme.Text
$openTrayItem = New-Object System.Windows.Forms.ToolStripMenuItem
$openTrayItem.Text = 'Open Plex Goblin'
$openTrayItem.Font = New-Object System.Drawing.Font('Segoe UI', 9, [Drawing.FontStyle]::Bold)
$startupTrayItem = New-Object System.Windows.Forms.ToolStripMenuItem
$startupTrayItem.Text = 'Start with Windows'
$startupTrayItem.Checked = [bool]$startupCheck.Checked
$traySeparator = New-Object System.Windows.Forms.ToolStripSeparator
$exitTrayItem = New-Object System.Windows.Forms.ToolStripMenuItem
$exitTrayItem.Text = 'Exit and Allow Everyone'
$trayMenu.Items.Add($openTrayItem) | Out-Null
$trayMenu.Items.Add($startupTrayItem) | Out-Null
$trayMenu.Items.Add($traySeparator) | Out-Null
$trayMenu.Items.Add($exitTrayItem) | Out-Null

$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Text = 'Plex Goblin - running'
$notifyIcon.Icon = if ($null -ne $form.Icon) { $form.Icon } else { [Drawing.SystemIcons]::Application }
$notifyIcon.ContextMenuStrip = $trayMenu
$notifyIcon.Visible = $true

function Update-AutostartControls {
    $enabled = Test-PlexGoblinAutostart
    $script:UpdatingStartupUi = $true
    try {
        $startupCheck.Checked = $enabled
        $startupTrayItem.Checked = $enabled
    }
    finally { $script:UpdatingStartupUi = $false }
}

function Request-AutostartChange {
    param([Parameter(Mandatory = $true)][bool]$Enabled)
    try {
        Set-PlexGoblinAutostart -Enabled $Enabled
        Update-AutostartControls
        $message = if ($Enabled) {
            'Plex Goblin will start silently in the notification area when this Windows account signs in.'
        }
        else { 'Plex Goblin Windows autostart is disabled.' }
        $statusText.Text = $message
        Write-AppLog $message
    }
    catch {
        Update-AutostartControls
        [PlexGoblin.GoblinMessage]::Show(
            "Plex Goblin could not change Windows autostart.`r`n`r`n$($_.Exception.Message)",
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Show-PlexGoblinWindow {
    if ($form.IsDisposed) { return }
    $form.Opacity = 1
    $form.ShowInTaskbar = $true
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Show()
    $form.Activate()
    $form.BringToFront()
}

function Hide-PlexGoblinWindow {
    param([switch]$Silent)
    if ($form.IsDisposed) { return }
    $form.Hide()
    $form.ShowInTaskbar = $false
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Opacity = 1
    if (-not $Silent -and -not $script:TrayHintShown) {
        $notifyIcon.ShowBalloonTip(
            3000,
            'Plex Goblin is still running',
            'Double-click the tray icon to reopen it. Use Exit and Allow Everyone to stop it.',
            [System.Windows.Forms.ToolTipIcon]::Info
        )
        $script:TrayHintShown = $true
    }
}

function Request-PlexGoblinExit {
    $script:ExitRequested = $true
    $form.Close()
}

Initialize-StreamGoblinUi -TabPage $streamGoblinTab -Theme $theme -ParentForm $form

$pollTimer = New-Object System.Windows.Forms.Timer
$pollTimer.Interval = 750
$activationTimer = New-Object System.Windows.Forms.Timer
$activationTimer.Interval = 300

function Update-StatusText {
    $statusText.Text = '{0} shared; {1} blocked; {2} timed; {3} session(s) stopped' -f `
        $script:Users.Count, $script:BlockedUserIds.Count, $script:AutoAllowDeadlines.Count, $script:StoppedCount
}

function Get-AutoAllowDisplay {
    param(
        [Parameter(Mandatory = $true)][string]$UserId,
        [datetime]$Now = (Get-Date)
    )
    if (-not $script:AutoAllowDeadlines.ContainsKey($UserId)) { return '' }
    $remainingSeconds = [int][Math]::Ceiling((([datetime]$script:AutoAllowDeadlines[$UserId]) - $Now).TotalSeconds)
    if ($remainingSeconds -lt 0) { $remainingSeconds = 0 }
    $hours = [int][Math]::Floor($remainingSeconds / 3600)
    $minutes = [int][Math]::Floor(($remainingSeconds % 3600) / 60)
    $seconds = $remainingSeconds % 60
    return ('{0:00}:{1:00}:{2:00}' -f $hours, $minutes, $seconds)
}

function Apply-GridSelectionsToMemory {
    $newBlocklist = @{}
    foreach ($row in $grid.Rows) {
        $userId = [string]$row.Cells['UserId'].Value
        $isBlocked = [bool]$row.Cells['Blocked'].Value
        if ($isBlocked -and -not [string]::IsNullOrWhiteSpace($userId)) {
            $newBlocklist[$userId] = $true
            $row.Cells['Status'].Value = 'Blocked'
            $row.Cells['Timer'].Value = Get-AutoAllowDisplay -UserId $userId
            $row.DefaultCellStyle.BackColor = $theme.Blocked
        }
        else {
            if (-not [string]::IsNullOrWhiteSpace($userId) -and $script:AutoAllowDeadlines.ContainsKey($userId)) {
                $script:AutoAllowDeadlines.Remove($userId) | Out-Null
            }
            $row.Cells['Status'].Value = 'Allowed'
            $row.Cells['Timer'].Value = ''
            if (($row.Index % 2) -eq 0) {
                $row.DefaultCellStyle.BackColor = $theme.Surface
            }
            else {
                $row.DefaultCellStyle.BackColor = $theme.AlternateRow
            }
        }
        $row.DefaultCellStyle.ForeColor = $theme.Text
    }
    $script:BlockedUserIds = $newBlocklist
    Update-StatusText
}

function Refresh-Grid {
    $refreshButton.Enabled = $false
    $form.UseWaitCursor = $true
    $statusText.Text = 'Loading shared Plex accounts...'
    [System.Windows.Forms.Application]::DoEvents()
    try {
        # Preserve selections across refresh only in memory, never on disk.
        $previousBlocklist = $script:BlockedUserIds
        $knownUserIds = @{}
        $script:Users = @(Get-SharedUsers)
        $grid.Rows.Clear()
        foreach ($user in $script:Users) {
            $userId = [string]$user.Id
            $knownUserIds[$userId] = $true
            $blocked = $previousBlocklist.ContainsKey($userId)
            $status = if ($blocked) { 'Blocked' } else { 'Allowed' }
            $timerText = Get-AutoAllowDisplay -UserId $userId
            $index = $grid.Rows.Add($blocked, $status, $timerText, $user.Username, $user.Email, $user.Libraries, $user.Id)
            if ($blocked) { $grid.Rows[$index].DefaultCellStyle.BackColor = $theme.Blocked }
        }
        foreach ($userId in @($script:AutoAllowDeadlines.Keys)) {
            if (-not $knownUserIds.ContainsKey([string]$userId)) {
                $script:AutoAllowDeadlines.Remove($userId) | Out-Null
            }
        }
        Apply-GridSelectionsToMemory
        Refresh-GoblinTargetGrid
    }
    catch {
        Write-AppLog "User refresh failed: $($_.Exception.Message)"
        [PlexGoblin.GoblinMessage]::Show(
            "Could not load shared Plex users. No Plex settings were changed.`r`n`r`n$($_.Exception.Message)",
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        $statusText.Text = 'User refresh failed; no persistent setting was changed'
    }
    finally {
        $refreshButton.Enabled = $true
        $form.UseWaitCursor = $false
    }
}

function Show-TimedBlockDialog {
    param([Parameter(Mandatory = $true)][string]$UserName)

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Timed Block'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.ClientSize = New-Object System.Drawing.Size(390, 180)
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowInTaskbar = $false
    $dialog.Font = $form.Font
    $dialog.BackColor = $theme.Window
    $dialog.ForeColor = $theme.Text
    if (Test-Path -LiteralPath $iconPath) { $dialog.Icon = New-Object System.Drawing.Icon($iconPath) }

    $dialogLabel = New-Object System.Windows.Forms.Label
    $dialogLabel.Text = "Block $UserName now, then automatically allow after:"
    $dialogLabel.Location = New-Object System.Drawing.Point(18, 18)
    $dialogLabel.Size = New-Object System.Drawing.Size(350, 38)
    $dialog.Controls.Add($dialogLabel)

    $minutesLabel = New-Object System.Windows.Forms.Label
    $minutesLabel.Text = 'Minutes:'
    $minutesLabel.AutoSize = $true
    $minutesLabel.Location = New-Object System.Drawing.Point(20, 68)
    $dialog.Controls.Add($minutesLabel)

    $duration = New-Object System.Windows.Forms.NumericUpDown
    $duration.Location = New-Object System.Drawing.Point(85, 64)
    $duration.Size = New-Object System.Drawing.Size(105, 25)
    $duration.Minimum = 1
    $duration.Maximum = 10080
    $duration.Value = 60
    $duration.BackColor = $theme.Surface
    $duration.ForeColor = $theme.Text
    $duration.BorderStyle = 'FixedSingle'
    $dialog.Controls.Add($duration)

    $limitLabel = New-Object System.Windows.Forms.Label
    $limitLabel.Text = '1 minute to 7 days. Plex Goblin must remain open.'
    $limitLabel.AutoSize = $true
    $limitLabel.ForeColor = $theme.MutedText
    $limitLabel.Location = New-Object System.Drawing.Point(20, 101)
    $dialog.Controls.Add($limitLabel)

    $startButton = New-Object System.Windows.Forms.Button
    $startButton.Text = 'Block Now'
    $startButton.Location = New-Object System.Drawing.Point(196, 136)
    $startButton.Size = New-Object System.Drawing.Size(84, 30)
    $startButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $startButton.BackColor = $theme.Success
    $startButton.ForeColor = $theme.Text
    $startButton.FlatStyle = 'Flat'
    $startButton.FlatAppearance.BorderColor = $theme.Border
    $startButton.UseVisualStyleBackColor = $false
    $dialog.Controls.Add($startButton)

    $cancelButton = New-Object System.Windows.Forms.Button
    $cancelButton.Text = 'Cancel'
    $cancelButton.Location = New-Object System.Drawing.Point(288, 136)
    $cancelButton.Size = New-Object System.Drawing.Size(84, 30)
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $cancelButton.BackColor = $theme.Button
    $cancelButton.ForeColor = $theme.Text
    $cancelButton.FlatStyle = 'Flat'
    $cancelButton.FlatAppearance.BorderColor = $theme.Border
    $cancelButton.UseVisualStyleBackColor = $false
    $dialog.Controls.Add($cancelButton)

    $dialog.AcceptButton = $startButton
    $dialog.CancelButton = $cancelButton
    Set-GoblinCompactDialog -Dialog $dialog -Fields @($dialogLabel, $minutesLabel, $duration, $limitLabel) -Buttons @($startButton, $cancelButton)
    Set-GoblinDarkSurface -Control $dialog
    if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        return [int]$duration.Value
    }
    return $null
}

function Update-AutoAllowTimers {
    $now = Get-Date
    $expiredUserIds = @()
    foreach ($userId in @($script:AutoAllowDeadlines.Keys)) {
        if ([datetime]$script:AutoAllowDeadlines[$userId] -le $now) {
            $expiredUserIds += [string]$userId
        }
    }

    $script:UpdatingGrid = $true
    try {
        foreach ($userId in $expiredUserIds) {
            $script:AutoAllowDeadlines.Remove($userId) | Out-Null
            foreach ($row in $grid.Rows) {
                if ([string]$row.Cells['UserId'].Value -eq $userId) {
                    $row.Cells['Blocked'].Value = $false
                    $row.Cells['Timer'].Value = ''
                    Write-AppLog "Timed block expired for user $($row.Cells['Username'].Value) (ID $userId)."
                    break
                }
            }
        }

        foreach ($row in $grid.Rows) {
            $userId = [string]$row.Cells['UserId'].Value
            if ($script:AutoAllowDeadlines.ContainsKey($userId)) {
                $row.Cells['Timer'].Value = Get-AutoAllowDisplay -UserId $userId -Now $now
            }
        }
    }
    finally { $script:UpdatingGrid = $false }

    if ($expiredUserIds.Count -gt 0) {
        Apply-GridSelectionsToMemory
        $activity.Text = '{0} timed block(s) expired at {1:T}; those users are now allowed.' -f $expiredUserIds.Count, (Get-Date)
    }
    else { Update-StatusText }
}

function Invoke-BlockSweep {
    if ($script:Polling -or $script:BlockedUserIds.Count -eq 0) { return }
    $script:Polling = $true
    try {
        $now = Get-Date
        foreach ($key in @($script:RecentlyStopped.Keys)) {
            if (($now - [datetime]$script:RecentlyStopped[$key]).TotalSeconds -gt 15) {
                $script:RecentlyStopped.Remove($key)
            }
        }
        foreach ($session in @(Get-ActiveSessions)) {
            if (-not $script:BlockedUserIds.ContainsKey([string]$session.UserId)) { continue }
            if ([string]::IsNullOrWhiteSpace($session.SessionId)) { continue }

            # Match only Plex's account ID. Names are deliberately never used
            # because two accounts can have the same display name.
            # Always send the stop request while this session belongs to a
            # blocked user. Plex clients can reuse a session ID for a new play
            # attempt, so deduplicating by ID would let an immediate retry play.
            $firstRecentStop = -not $script:RecentlyStopped.ContainsKey([string]$session.SessionId)
            Stop-PlexSession -SessionId ([string]$session.SessionId)
            $script:RecentlyStopped[[string]$session.SessionId] = Get-Date
            if ($firstRecentStop) {
                # Recent IDs suppress duplicate log/count entries only. They
                # never suppress enforcement.
                $script:StoppedCount++
                $displayTitle = if ([string]::IsNullOrWhiteSpace($session.MediaTitle)) {
                    $session.ItemTitle
                } else {
                    "$($session.MediaTitle) - $($session.ItemTitle)"
                }
                $activity.Text = 'Last stopped: {0} playing {1} at {2:T}' -f $session.UserTitle, $displayTitle, (Get-Date)
                Write-AppLog "Stopped playback session for user $($session.UserTitle) (ID $($session.UserId))."
            }
        }
        $script:LastPollError = ''
        Update-StatusText
    }
    catch {
        $message = $_.Exception.Message
        if ($message -ne $script:LastPollError) {
            Write-AppLog "Session watcher error: $message"
            $script:LastPollError = $message
        }
        $statusText.Text = 'Watcher temporarily cannot reach local Plex; it will keep retrying'
    }
    finally { $script:Polling = $false }
}

$grid.Add_CurrentCellDirtyStateChanged({
    if ($grid.IsCurrentCellDirty) {
        $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit) | Out-Null
    }
})
$grid.Add_CellValueChanged({
    param($sender, $eventArgs)
    if ($script:UpdatingGrid) { return }
    if ($eventArgs.RowIndex -ge 0 -and $grid.Columns[$eventArgs.ColumnIndex].Name -eq 'Blocked') {
        Apply-GridSelectionsToMemory
        Invoke-BlockSweep
    }
})
$blockAllButton.Add_Click({
    foreach ($row in $grid.Rows) { $row.Cells['Blocked'].Value = $true }
    Apply-GridSelectionsToMemory
    Invoke-BlockSweep
})
$allowAllButton.Add_Click({
    $script:AutoAllowDeadlines = @{}
    foreach ($row in $grid.Rows) { $row.Cells['Blocked'].Value = $false }
    Apply-GridSelectionsToMemory
})
$timedBlockButton.Add_Click({
    $row = $grid.CurrentRow
    if ($null -eq $row) {
        [PlexGoblin.GoblinMessage]::Show(
            'Select a shared Plex user first.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $userId = [string]$row.Cells['UserId'].Value
    $userName = [string]$row.Cells['Username'].Value
    if ([string]::IsNullOrWhiteSpace($userName)) { $userName = [string]$row.Cells['Email'].Value }
    $minutes = Show-TimedBlockDialog -UserName $userName
    if ($null -eq $minutes) { return }

    $script:AutoAllowDeadlines[$userId] = (Get-Date).AddMinutes([int]$minutes)
    $script:UpdatingGrid = $true
    try { $row.Cells['Blocked'].Value = $true }
    finally { $script:UpdatingGrid = $false }
    Apply-GridSelectionsToMemory
    Update-AutoAllowTimers
    Invoke-BlockSweep
    $activity.Text = '{0} blocked for {1} minute(s); automatic allow is armed.' -f $userName, $minutes
})
$refreshButton.Add_Click({ Refresh-Grid })
$closeButton.Add_Click({ Request-PlexGoblinExit })
$startupCheck.Add_CheckedChanged({
    if (-not $script:UpdatingStartupUi) {
        Request-AutostartChange -Enabled ([bool]$startupCheck.Checked)
    }
})
$openTrayItem.Add_Click({ Show-PlexGoblinWindow })
$startupTrayItem.Add_Click({ Request-AutostartChange -Enabled (-not [bool]$startupTrayItem.Checked) })
$exitTrayItem.Add_Click({ Request-PlexGoblinExit })
$notifyIcon.Add_DoubleClick({ Show-PlexGoblinWindow })
$pollTimer.Add_Tick({
    Update-AutoAllowTimers
    Invoke-BlockSweep
})
$activationTimer.Add_Tick({
    if ($script:ActivationEvent.WaitOne(0)) { Show-PlexGoblinWindow }
})
$form.Add_Resize({
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
        Hide-PlexGoblinWindow
    }
})
$form.Add_Shown({
    Set-GoblinDarkSurface -Control $form
    Set-GoblinDarkSurface -Control $trayMenu
    Update-PauseTabLayout
    Update-AutostartControls
    Refresh-Grid
    Initialize-StreamGoblinFeature
    $pollTimer.Start()
    $activationTimer.Start()
    Update-StatusText
    if ($StartHidden) { Hide-PlexGoblinWindow -Silent }
})
$form.Add_FormClosing({
    param($sender, $eventArgs)
    if (-not $script:ExitRequested -and
        $eventArgs.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing) {
        $eventArgs.Cancel = $true
        Hide-PlexGoblinWindow
        return
    }

    $script:ExitRequested = $true
    $pollTimer.Stop()
    $activationTimer.Stop()
    Close-StreamGoblinFeature
    # Plex received no blocklist, so there is nothing to restore. Clearing this
    # in-memory map merely makes the fail-open lifecycle explicit.
    $script:BlockedUserIds = @{}
    $script:AutoAllowDeadlines = @{}
    $notifyIcon.Visible = $false
    $notifyIcon.Dispose()
    $trayMenu.Dispose()
    $script:ActivationEvent.Dispose()
    $script:InstanceLock.Dispose()
})

[System.Windows.Forms.Application]::Run($form)

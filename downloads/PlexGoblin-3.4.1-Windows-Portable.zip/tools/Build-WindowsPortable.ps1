﻿[CmdletBinding()]
param([string]$Destination = (Join-Path $PSScriptRoot '..\dist'))
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
# Explicit staging list: never copy an installed Data folder into a download.
$files = @('PlexGoblin.ps1','StreamGoblinEngine.ps1','GoblinTheme.ps1',
    'Launch Plex Goblin.vbs','PlexGoblin.ico','LICENSE','README.txt','README.md','CHANGELOG.md','SECURITY.md',
    'Start Plex Goblin.cmd','Create Desktop Shortcut.cmd','Data\README.txt',
    'tools\Build-WindowsPortable.ps1','tools\Test-WindowsUi.ps1')
foreach ($name in @('PlexGoblin.ps1','StreamGoblinEngine.ps1','GoblinTheme.ps1')) {
    $tokens = $null; $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root $name), [ref]$tokens, [ref]$errors) | Out-Null
    if ($errors.Count) { throw ($errors | Out-String) }
}
$stage = Join-Path $env:TEMP ('PlexGoblin-Package-' + [guid]::NewGuid())
try {
    foreach ($name in $files) {
        $target = Join-Path $stage $name
        New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath (Join-Path $root $name) -Destination $target
    }
    New-Item -ItemType Directory -Force $Destination | Out-Null
    $zip = Join-Path $Destination 'PlexGoblin-3.4.1-Windows-Portable.zip'
    if (Test-Path -LiteralPath $zip) { throw 'Destination exists. Choose a fresh output folder.' }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip
    Get-FileHash -Algorithm SHA256 -LiteralPath $zip
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}

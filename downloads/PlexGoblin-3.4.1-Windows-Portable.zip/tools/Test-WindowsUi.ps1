﻿# Offline WinForms smoke test. No Plex/Tautulli requests or startup registration.
[CmdletBinding()]
param([string]$ScreenshotDirectory = (Join-Path $PSScriptRoot '..\Data\UiChecks'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$root = Split-Path -Parent $PSScriptRoot
Get-ChildItem $root -Filter '*.ps1' | ForEach-Object {
    $tokens = $null; $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    if ($errors.Count) { throw ($errors | Out-String) }
}
. (Join-Path $root 'GoblinTheme.ps1')
$script:DataDirectory = Join-Path $env:TEMP ('PlexGoblin-UiCheck-' + [guid]::NewGuid())
. (Join-Path $root 'StreamGoblinEngine.ps1')
function Test-PlexGoblinAutostart { return $false }
$script:AppName = 'Plex Goblin'; $script:AppVersion = '3.4.1-preview'
$script:OwnerName = 'Protected owner (test)'; $StartHidden = $false
$source = Get-Content (Join-Path $root 'PlexGoblin.ps1') -Raw
$begin = $source.IndexOf('$theme = @{')
$end = $source.IndexOf('$trayMenu = ', $begin)
# Evaluate only the UI construction section, never the application's startup.
. ([scriptblock]::Create($source.Substring($begin, $end - $begin).Replace('$PSScriptRoot', '$root')))
Initialize-StreamGoblinUi -TabPage $streamGoblinTab -Theme $theme -ParentForm $form
Set-GoblinDarkSurface $form
New-Item -ItemType Directory -Force $ScreenshotDirectory | Out-Null
try {
    foreach ($name in @('Demo viewer', 'Another viewer')) {
        $grid.Rows.Add($false, 'Allowed', '', $name, '', 'Movies / Music', '') | Out-Null
        $script:GoblinTargetGrid.Rows.Add($true, $name, 10, 15) | Out-Null
        $script:GoblinMonitorGrid.Rows.Add($name, 'Demo title', 'playing', '12:00', '06:00', 50, 'demo', $false) | Out-Null
    }
    $form.Show()
    foreach ($size in @(@(420,560), @(800,600), @(1024,768), @(1280,800))) {
        $form.Size = New-Object Drawing.Size($size[0], $size[1])
        foreach ($tab in @(0,1,2)) {
            $tabControl.SelectedIndex = $tab
            $form.PerformLayout(); [Windows.Forms.Application]::DoEvents()
            if ($tab -eq 0) {
                foreach ($button in @($timedBlockButton,$closeButton)) {
                    $point = $pauseTab.PointToClient($button.PointToScreen([Drawing.Point]::Empty))
                    if ($point.X -lt 0 -or $point.Y -lt 0 -or $point.X + $button.Width -gt $pauseTab.ClientSize.Width -or $point.Y + $button.Height -gt $pauseTab.ClientSize.Height) { throw "Unreachable action at $size" }
                }
                if ($grid.Height -lt 36) { throw "Grid collapsed at $size" }
            }
            $bitmap = New-Object Drawing.Bitmap($form.Width, $form.Height)
            try {
                $form.DrawToBitmap($bitmap, (New-Object Drawing.Rectangle(0,0,$form.Width,$form.Height)))
                $bitmap.Save((Join-Path $ScreenshotDirectory ('{0}x{1}-tab{2}.png' -f $size[0],$size[1],$tab)))
            } finally { $bitmap.Dispose() }
        }
    }
    Write-Output 'PASS: Windows UI construction, resizing, action visibility and bitmap captures. No live playback tested.'
} finally {
    $script:GoblinWorkerTimer.Dispose(); $script:GoblinUiTimer.Dispose(); $form.Dispose()
}

﻿# Stream Goblin and Monitor Goblin integration for Plex Goblin.
# This file is dot-sourced by PlexGoblin.ps1 and has no standalone console UI.

$script:GoblinRoot = Join-Path $script:DataDirectory 'StreamGoblin'
$script:GoblinConfigPath = Join-Path $script:GoblinRoot 'config.json'
$script:GoblinConfigTempPath = Join-Path $script:GoblinRoot 'config.tmp'
$script:GoblinApiKeyPath = Join-Path $script:GoblinRoot 'tautulli-key.dat'
$script:GoblinStatusPath = Join-Path $script:GoblinRoot 'status.json'
$script:GoblinStatusTempPath = Join-Path $script:GoblinRoot 'status.tmp'
$script:GoblinApiKeyTempPath = Join-Path $script:GoblinRoot 'tautulli-key.tmp'
$script:GoblinLogsDirectory = Join-Path $script:GoblinRoot 'Logs'
$script:LegacyGoblinRoot = 'C:\StreamGoblin'
$script:GoblinTautulliUrl = 'http://127.0.0.1:8181'
$script:GoblinApiKey = ''
$script:GoblinErrorMessage = 'Playback error. Please try again.'
$script:GoblinTargets = @{}
$script:GoblinTracked = @{}
$script:GoblinConfigured = $false
$script:GoblinEngineRunning = $false
$script:GoblinPolling = $false
$script:GoblinLastError = ''
$script:GoblinLastCleanup = [datetime]::MinValue
$script:GoblinTheme = $null
$script:GoblinParentForm = $null
$script:GoblinTargetGrid = $null
$script:GoblinMonitorGrid = $null
$script:GoblinLogBox = $null
$script:GoblinConnectionLabel = $null
$script:GoblinWorkerLabel = $null
$script:GoblinToggleButton = $null
$script:GoblinErrorBox = $null
$script:GoblinWorkerTimer = $null
$script:GoblinUiTimer = $null

function Get-GoblinObjectValue {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { return $Default }
    return $property.Value
}

function Get-GoblinMonotonicSeconds {
    return ([Diagnostics.Stopwatch]::GetTimestamp() / [double][Diagnostics.Stopwatch]::Frequency)
}

function Format-GoblinTime {
    param([double]$Seconds)
    $wholeSeconds = [int][Math]::Max(0, [Math]::Floor($Seconds))
    $minutes = [int][Math]::Floor($wholeSeconds / 60)
    $secondsLeft = $wholeSeconds % 60
    return ('{0:00}:{1:00}' -f $minutes, $secondsLeft)
}

function Complete-GoblinAtomicWrite {
    param(
        [Parameter(Mandatory = $true)][string]$TempPath,
        [Parameter(Mandatory = $true)][string]$Path
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        [IO.File]::Move($TempPath, $Path)
        return
    }

    # File.Replace requires a legal backup filename on the Windows/.NET
    # version used by Plex Goblin. A unique same-directory backup preserves
    # the old complete file until the atomic replacement succeeds.
    $backupPath = $Path + '.' + [Guid]::NewGuid().ToString('N') + '.previous'
    [IO.File]::Replace($TempPath, $Path, $backupPath)
    try {
        if (Test-Path -LiteralPath $backupPath -PathType Leaf) {
            [IO.File]::Delete($backupPath)
        }
    }
    catch {
        # The new file is already committed. A leftover uniquely named backup
        # is harmless and preferable to turning a successful save into failure.
    }
}

function Write-GoblinJsonAtomically {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$TempPath,
        [Parameter(Mandatory = $true)]$Value
    )
    $json = $Value | ConvertTo-Json -Depth 8
    $encoding = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [IO.File]::WriteAllText($TempPath, $json, $encoding)
    Complete-GoblinAtomicWrite -TempPath $TempPath -Path $Path
}

function Protect-GoblinApiKey {
    param([Parameter(Mandatory = $true)][string]$ApiKey)
    $bytes = [Text.Encoding]::UTF8.GetBytes($ApiKey)
    $protected = [Security.Cryptography.ProtectedData]::Protect(
        $bytes,
        $null,
        [Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    [IO.File]::WriteAllBytes($script:GoblinApiKeyTempPath, $protected)
    Complete-GoblinAtomicWrite -TempPath $script:GoblinApiKeyTempPath -Path $script:GoblinApiKeyPath
}

function Read-ProtectedGoblinApiKey {
    if (-not (Test-Path -LiteralPath $script:GoblinApiKeyPath)) { return '' }
    try {
        $protected = [IO.File]::ReadAllBytes($script:GoblinApiKeyPath)
        $bytes = [Security.Cryptography.ProtectedData]::Unprotect(
            $protected,
            $null,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        return [Text.Encoding]::UTF8.GetString($bytes)
    }
    catch {
        Write-AppLog "Could not read the saved Tautulli API key: $($_.Exception.Message)"
        return ''
    }
}

function Import-GoblinTargetsFromObject {
    param($TargetsObject)
    $targets = @{}
    if ($null -eq $TargetsObject) { return $targets }
    foreach ($property in @($TargetsObject.PSObject.Properties)) {
        $name = [string]$property.Name
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        $enabled = [bool](Get-GoblinObjectValue -Object $property.Value -Name 'enabled' -Default $false)
        $minimum = [int](Get-GoblinObjectValue -Object $property.Value -Name 'minimum_minutes' -Default 10)
        $maximum = [int](Get-GoblinObjectValue -Object $property.Value -Name 'maximum_minutes' -Default 15)
        if ($minimum -lt 1) { $minimum = 1 }
        if ($minimum -gt 10080) { $minimum = 10080 }
        if ($maximum -lt $minimum) { $maximum = $minimum }
        if ($maximum -gt 10080) { $maximum = 10080 }
        $targets[$name] = @{
            Enabled = $enabled
            MinimumMinutes = $minimum
            MaximumMinutes = $maximum
        }
    }
    return $targets
}

function Save-GoblinConfiguration {
    $targets = [ordered]@{}
    foreach ($name in @($script:GoblinTargets.Keys | Sort-Object)) {
        $target = $script:GoblinTargets[$name]
        $targets[[string]$name] = [ordered]@{
            enabled = [bool]$target['Enabled']
            minimum_minutes = [int]$target['MinimumMinutes']
            maximum_minutes = [int]$target['MaximumMinutes']
        }
    }
    $payload = [ordered]@{
        tautulli_url = $script:GoblinTautulliUrl
        error_message = $script:GoblinErrorMessage
        targets = $targets
    }
    Write-GoblinJsonAtomically -Path $script:GoblinConfigPath -TempPath $script:GoblinConfigTempPath -Value $payload
}

function Copy-LegacyGoblinLogs {
    $legacyLogs = Join-Path $script:LegacyGoblinRoot 'Logs'
    if (Test-Path -LiteralPath $legacyLogs -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $legacyLogs -Filter '* GoblinLog.txt' -File -ErrorAction SilentlyContinue)) {
            if ($file.Name -notmatch '^\d{2}-\d{2}-\d{4} GoblinLog\.txt$') { continue }
            $destination = Join-Path $script:GoblinLogsDirectory $file.Name
            if (-not (Test-Path -LiteralPath $destination)) {
                try { [IO.File]::Copy($file.FullName, $destination, $false) }
                catch { Write-AppLog "Could not import legacy Goblin log $($file.Name): $($_.Exception.Message)" }
            }
        }
    }
    $legacyFlatLog = Join-Path $script:LegacyGoblinRoot 'stream_goblin.log'
    $importedFlatLog = Join-Path $script:GoblinLogsDirectory 'legacy-stream_goblin.log'
    if ((Test-Path -LiteralPath $legacyFlatLog -PathType Leaf) -and -not (Test-Path -LiteralPath $importedFlatLog)) {
        try { [IO.File]::Copy($legacyFlatLog, $importedFlatLog, $false) }
        catch { Write-AppLog "Could not import legacy stream_goblin.log: $($_.Exception.Message)" }
    }
}

function Initialize-GoblinConfiguration {
    foreach ($directory in @($script:GoblinRoot, $script:GoblinLogsDirectory)) {
        if (-not (Test-Path -LiteralPath $directory)) {
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
        }
    }

    $config = $null
    $importedLegacy = $false
    if (Test-Path -LiteralPath $script:GoblinConfigPath) {
        try { $config = Get-Content -LiteralPath $script:GoblinConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { Write-AppLog "Could not read Stream Goblin configuration: $($_.Exception.Message)" }
    }
    elseif (Test-Path -LiteralPath (Join-Path $script:LegacyGoblinRoot 'config.json')) {
        try {
            $config = Get-Content -LiteralPath (Join-Path $script:LegacyGoblinRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
            $importedLegacy = $true
        }
        catch { Write-AppLog "Could not import C:\StreamGoblin\config.json: $($_.Exception.Message)" }
    }

    if ($null -ne $config) {
        $url = [string](Get-GoblinObjectValue -Object $config -Name 'tautulli_url' -Default $script:GoblinTautulliUrl)
        if (-not [string]::IsNullOrWhiteSpace($url)) { $script:GoblinTautulliUrl = $url.TrimEnd('/') }
        $message = [string](Get-GoblinObjectValue -Object $config -Name 'error_message' -Default $script:GoblinErrorMessage)
        if (-not [string]::IsNullOrWhiteSpace($message)) { $script:GoblinErrorMessage = $message }
        if ($script:GoblinErrorMessage.Length -gt 500) { $script:GoblinErrorMessage = $script:GoblinErrorMessage.Substring(0, 500) }
        $script:GoblinTargets = Import-GoblinTargetsFromObject -TargetsObject (Get-GoblinObjectValue -Object $config -Name 'targets')
    }

    $script:GoblinApiKey = Read-ProtectedGoblinApiKey
    $migratedPlaintextKey = $false
    if ([string]::IsNullOrWhiteSpace($script:GoblinApiKey) -and $null -ne $config) {
        $legacyKey = [string](Get-GoblinObjectValue -Object $config -Name 'tautulli_api_key' -Default '')
        if (-not [string]::IsNullOrWhiteSpace($legacyKey)) {
            $script:GoblinApiKey = $legacyKey.Trim()
            Protect-GoblinApiKey -ApiKey $script:GoblinApiKey
            $migratedPlaintextKey = $true
        }
    }

    if ($importedLegacy) {
        Copy-LegacyGoblinLogs
    }
    if ($importedLegacy -or $migratedPlaintextKey) {
        Save-GoblinConfiguration
    }
    if ($importedLegacy) {
        Write-GoblinLog 'Goblin hauled the old C:\StreamGoblin settings and logs into its new lair.'
    }

    $script:GoblinConfigured = ((-not [string]::IsNullOrWhiteSpace($script:GoblinApiKey)) -and
        (Test-GoblinTautulliUrl -Url $script:GoblinTautulliUrl))
    Cleanup-GoblinLogs
}

function Get-GoblinDailyLogPath {
    $now = Get-Date
    $path = Join-Path $script:GoblinLogsDirectory ($now.ToString('MM-dd-yyyy') + ' GoblinLog.txt')
    if (-not (Test-Path -LiteralPath $path)) {
        $header = "========================================`r`n          STREAM GOBLIN LOG`r`n========================================`r`nDate: $($now.ToString('MM-dd-yyyy'))`r`nCreated: $($now.ToString('hh:mm:ss tt'))`r`n========================================`r`n`r`n"
        try { [IO.File]::WriteAllText($path, $header, (New-Object System.Text.UTF8Encoding -ArgumentList $false)) }
        catch { }
    }
    return $path
}

function Write-GoblinLog {
    param([Parameter(Mandatory = $true)][string]$Message)
    $safeMessage = $Message.Replace("`r", ' ').Replace("`n", ' ')
    $line = '{0} | {1}' -f (Get-Date -Format 'hh:mm:ss tt'), $safeMessage
    try {
        $path = Get-GoblinDailyLogPath
        [IO.File]::AppendAllText($path, $line + "`r`n", (New-Object System.Text.UTF8Encoding -ArgumentList $false))
    }
    catch { }

    if ($null -ne $script:GoblinLogBox -and -not $script:GoblinLogBox.IsDisposed) {
        $script:GoblinLogBox.AppendText($line + "`r`n")
        if ($script:GoblinLogBox.TextLength -gt 120000) {
            $script:GoblinLogBox.Select(0, 30000)
            $script:GoblinLogBox.SelectedText = ''
        }
        $script:GoblinLogBox.SelectionStart = $script:GoblinLogBox.TextLength
        $script:GoblinLogBox.ScrollToCaret()
    }
}

function Cleanup-GoblinLogs {
    if (-not (Test-Path -LiteralPath $script:GoblinLogsDirectory -PathType Container)) { return }
    $cutoff = (Get-Date).AddDays(-7)
    $deleted = 0
    foreach ($file in @(Get-ChildItem -LiteralPath $script:GoblinLogsDirectory -Filter '* GoblinLog.txt' -File -ErrorAction SilentlyContinue)) {
        if ($file.Name -notmatch '^\d{2}-\d{2}-\d{4} GoblinLog\.txt$') { continue }
        if ($file.LastWriteTime -ge $cutoff) { continue }
        try {
            [IO.File]::Delete($file.FullName)
            $deleted++
        }
        catch { }
    }
    $script:GoblinLastCleanup = Get-Date
    if ($deleted -gt 0) { Write-GoblinLog "Goblin burned $deleted ancient log file(s)." }
}

function Test-GoblinTautulliUrl {
    param([string]$Url)
    try { $uri = [Uri]$Url }
    catch { return $false }
    if (-not $uri.IsAbsoluteUri) { return $false }
    if ($uri.Scheme -ne 'http' -and $uri.Scheme -ne 'https') { return $false }
    if (-not [string]::IsNullOrWhiteSpace($uri.UserInfo) -or
        -not [string]::IsNullOrWhiteSpace($uri.Query) -or
        -not [string]::IsNullOrWhiteSpace($uri.Fragment)) { return $false }
    $hostName = $uri.DnsSafeHost.ToLowerInvariant().Replace('[', '').Replace(']', '')
    if ($hostName -ne '127.0.0.1' -and $hostName -ne 'localhost' -and $hostName -ne '::1') { return $false }
    if ($uri.Port -lt 1 -or $uri.Port -gt 65535) { return $false }
    return $true
}

function Invoke-GoblinApi {
    param(
        [Parameter(Mandatory = $true)][ValidateSet('get_activity', 'terminate_session')][string]$Command,
        [hashtable]$Arguments = @{},
        [ValidateSet('GET', 'POST')][string]$Method = 'GET'
    )
    if (-not (Test-GoblinTautulliUrl -Url $script:GoblinTautulliUrl)) {
        throw 'Tautulli URL must use http or https on localhost, 127.0.0.1, or ::1.'
    }
    if ([string]::IsNullOrWhiteSpace($script:GoblinApiKey)) { throw 'Tautulli API key is not configured.' }

    $parameters = [ordered]@{ apikey = $script:GoblinApiKey; cmd = $Command }
    foreach ($key in $Arguments.Keys) { $parameters[[string]$key] = [string]$Arguments[$key] }
    $query = @($parameters.Keys | ForEach-Object {
        [Uri]::EscapeDataString([string]$_) + '=' + [Uri]::EscapeDataString([string]$parameters[$_])
    }) -join '&'
    $base = [Uri]$script:GoblinTautulliUrl
    $builder = New-Object System.UriBuilder -ArgumentList $base.AbsoluteUri
    $builder.Path = $base.AbsolutePath.TrimEnd('/') + '/api/v2'
    $builder.Query = $query

    try {
        $response = Invoke-WebRequest -Uri $builder.Uri.AbsoluteUri -Method $Method -UseBasicParsing -TimeoutSec 10
    }
    catch {
        # PowerShell's web exception text can include the complete request URL.
        # Tautulli authenticates in the query string, so redact both raw and
        # URL-encoded forms before the error reaches either log or dialog.
        $safeError = [string]$_.Exception.Message
        foreach ($secretForm in @($script:GoblinApiKey, [Uri]::EscapeDataString($script:GoblinApiKey))) {
            if (-not [string]::IsNullOrWhiteSpace($secretForm)) {
                $safeError = $safeError.Replace($secretForm, '[redacted]')
            }
        }
        throw "Tautulli request failed: $safeError"
    }
    $decoded = $response.Content | ConvertFrom-Json
    $result = Get-GoblinObjectValue -Object $decoded -Name 'response'
    if ($null -eq $result -or [string](Get-GoblinObjectValue -Object $result -Name 'result') -ne 'success') {
        $message = [string](Get-GoblinObjectValue -Object $result -Name 'message' -Default 'Tautulli API error')
        foreach ($secretForm in @($script:GoblinApiKey, [Uri]::EscapeDataString($script:GoblinApiKey))) {
            if (-not [string]::IsNullOrWhiteSpace($secretForm)) {
                $message = $message.Replace($secretForm, '[redacted]')
            }
        }
        throw $message
    }
    return Get-GoblinObjectValue -Object $result -Name 'data'
}

function Get-GoblinSessions {
    $data = Invoke-GoblinApi -Command 'get_activity'
    return @((Get-GoblinObjectValue -Object $data -Name 'sessions' -Default @()))
}

function Stop-GoblinSession {
    param([Parameter(Mandatory = $true)][string]$SessionId)
    if ([string]::IsNullOrWhiteSpace($SessionId) -or $SessionId.Length -gt 200 -or $SessionId -notmatch '^[A-Za-z0-9._:-]+$') {
        throw 'Tautulli returned an invalid session ID. The session was not touched.'
    }
    Invoke-GoblinApi -Command 'terminate_session' -Method 'POST' -Arguments @{
        session_id = $SessionId
        message = $script:GoblinErrorMessage
    } | Out-Null
}

function Get-GoblinTarget {
    param([string]$Username)
    foreach ($name in $script:GoblinTargets.Keys) {
        if ([string]$name -ieq $Username) { return $script:GoblinTargets[$name] }
    }
    return $null
}

function Test-GoblinTargetStillEnabled {
    param([Parameter(Mandatory = $true)][string]$Username)

    # Mirror the supplied worker's final safety check by rereading the saved
    # target configuration immediately before a strike. If the file cannot be
    # read, fail open for this strike instead of terminating the session.
    try {
        if (-not (Test-Path -LiteralPath $script:GoblinConfigPath -PathType Leaf)) { return $false }
        $saved = Get-Content -LiteralPath $script:GoblinConfigPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
        $savedTargets = Get-GoblinObjectValue -Object $saved -Name 'targets'
        if ($null -eq $savedTargets) { return $false }
        foreach ($property in @($savedTargets.PSObject.Properties)) {
            if ([string]$property.Name -ieq $Username) {
                return [bool](Get-GoblinObjectValue -Object $property.Value -Name 'enabled' -Default $false)
            }
        }
    }
    catch {
        Write-GoblinLog "$Username | Goblin could not confirm the final target setting, so the prey was spared"
    }
    return $false
}

function Write-GoblinStatus {
    $sessions = @()
    foreach ($sessionId in $script:GoblinTracked.Keys) {
        $info = $script:GoblinTracked[$sessionId]
        $remaining = [Math]::Max(0, [double]$info['GoalSeconds'] - [double]$info['PlayedSeconds'])
        $sessions += [ordered]@{
            username = $info['Username']
            title = $info['Title']
            session_id = $sessionId
            state = $info['LastState']
            goal_seconds = $info['GoalSeconds']
            played_seconds = $info['PlayedSeconds']
            remaining_seconds = $remaining
            terminated = $info['Terminated']
        }
    }
    $payload = [ordered]@{
        updated_unix = ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0)
        worker_pid = $PID
        sessions = $sessions
    }
    try { Write-GoblinJsonAtomically -Path $script:GoblinStatusPath -TempPath $script:GoblinStatusTempPath -Value $payload }
    catch { }
}

function Set-GoblinWorkerUiState {
    if ($null -eq $script:GoblinWorkerLabel) { return }
    $enabledTargetCount = @($script:GoblinTargets.Values | Where-Object { [bool]($_['Enabled']) }).Count
    if (-not $script:GoblinConfigured) {
        $script:GoblinConnectionLabel.Text = 'Tautulli: setup required'
        $script:GoblinConnectionLabel.ForeColor = $script:GoblinTheme.MutedText
        $script:GoblinWorkerLabel.Text = 'Stream Goblin: sleeping'
        $script:GoblinWorkerLabel.ForeColor = $script:GoblinTheme.MutedText
        $script:GoblinToggleButton.Text = 'Start Stream Goblin'
    }
    elseif ($script:GoblinEngineRunning) {
        $script:GoblinConnectionLabel.Text = "Tautulli: $($script:GoblinTautulliUrl)"
        $script:GoblinConnectionLabel.ForeColor = $script:GoblinTheme.Owner
        $script:GoblinWorkerLabel.Text = "Stream Goblin: awake; $enabledTargetCount target(s) enabled"
        $script:GoblinWorkerLabel.ForeColor = $script:GoblinTheme.Owner
        $script:GoblinToggleButton.Text = 'Stop Stream Goblin'
    }
    else {
        $script:GoblinConnectionLabel.Text = "Tautulli: $($script:GoblinTautulliUrl)"
        $script:GoblinConnectionLabel.ForeColor = $script:GoblinTheme.Owner
        $script:GoblinWorkerLabel.Text = 'Stream Goblin: sleeping'
        $script:GoblinWorkerLabel.ForeColor = $script:GoblinTheme.MutedText
        $script:GoblinToggleButton.Text = 'Start Stream Goblin'
    }
}

function Invoke-StreamGoblinSweep {
    if (-not $script:GoblinEngineRunning -or $script:GoblinPolling) { return }
    $script:GoblinPolling = $true
    try {
        if (((Get-Date) - $script:GoblinLastCleanup).TotalHours -ge 1) { Cleanup-GoblinLogs }
        $active = @(Get-GoblinSessions)
        $seen = @{}

        foreach ($session in $active) {
            $username = [string](Get-GoblinObjectValue -Object $session -Name 'username' -Default '')
            $sessionId = [string](Get-GoblinObjectValue -Object $session -Name 'session_id' -Default '')
            $state = ([string](Get-GoblinObjectValue -Object $session -Name 'state' -Default '')).ToLowerInvariant()
            $title = [string](Get-GoblinObjectValue -Object $session -Name 'full_title' -Default '')
            if ([string]::IsNullOrWhiteSpace($title)) { $title = [string](Get-GoblinObjectValue -Object $session -Name 'title' -Default 'Unknown') }
            if ([string]::IsNullOrWhiteSpace($sessionId)) { continue }

            $target = Get-GoblinTarget -Username $username
            if ($null -eq $target -or -not [bool]$target['Enabled']) {
                if ($script:GoblinTracked.ContainsKey($sessionId)) {
                    $old = $script:GoblinTracked[$sessionId]
                    $script:GoblinTracked.Remove($sessionId) | Out-Null
                    Write-GoblinLog "$($old['Username']) | Goblin called off | $($old['Title'])"
                }
                continue
            }

            $seen[$sessionId] = $true
            $now = Get-GoblinMonotonicSeconds
            if (-not $script:GoblinTracked.ContainsKey($sessionId)) {
                $minimumSeconds = [int]$target['MinimumMinutes'] * 60
                $maximumSeconds = [int]$target['MaximumMinutes'] * 60
                $goal = Get-Random -Minimum $minimumSeconds -Maximum ($maximumSeconds + 1)
                $script:GoblinTracked[$sessionId] = @{
                    Username = $username
                    Title = $title
                    GoalSeconds = $goal
                    PlayedSeconds = 0.0
                    LastCheck = $now
                    LastState = $state
                    PreviousState = $state
                    Terminated = $false
                }
                Write-GoblinLog "$username | Goblin spots prey | $title | Roll: $(Format-GoblinTime $goal)"
            }

            $info = $script:GoblinTracked[$sessionId]
            if ($title -ne [string]$info['Title'] -and -not [bool]$info['Terminated']) {
                $minimumSeconds = [int]$target['MinimumMinutes'] * 60
                $maximumSeconds = [int]$target['MaximumMinutes'] * 60
                $goal = Get-Random -Minimum $minimumSeconds -Maximum ($maximumSeconds + 1)
                Write-GoblinLog "$username | Prey changed form | $($info['Title']) -> $title | New Roll: $(Format-GoblinTime $goal)"
                $info['Title'] = $title
                $info['GoalSeconds'] = $goal
                $info['PlayedSeconds'] = 0.0
                $info['LastCheck'] = $now
                $info['LastState'] = $state
                $info['PreviousState'] = $state
                $info['Terminated'] = $false
            }

            $elapsed = $now - [double]$info['LastCheck']
            if ([string]$info['LastState'] -eq 'playing' -and $state -eq 'playing' -and -not [bool]$info['Terminated']) {
                $info['PlayedSeconds'] = [double]$info['PlayedSeconds'] + $elapsed
            }

            if ($state -ne [string]$info['PreviousState']) {
                $remaining = [Math]::Max(0, [double]$info['GoalSeconds'] - [double]$info['PlayedSeconds'])
                if ($state -eq 'paused') {
                    Write-GoblinLog "$username | Playback PAUSED | $title | Remaining: $(Format-GoblinTime $remaining)"
                }
                elseif ($state -eq 'playing') {
                    Write-GoblinLog "$username | Playback RESUMED | $title | Remaining: $(Format-GoblinTime $remaining)"
                }
                else {
                    Write-GoblinLog "$username | Playback state: $($state.ToUpperInvariant()) | $title"
                }
                $info['PreviousState'] = $state
            }

            $info['LastCheck'] = $now
            $info['LastState'] = $state

            if ([double]$info['PlayedSeconds'] -ge [double]$info['GoalSeconds'] -and -not [bool]$info['Terminated']) {
                if (-not (Test-GoblinTargetStillEnabled -Username $username)) {
                    Write-GoblinLog "$username | Goblin spared prey at the last second | $title"
                    $script:GoblinTracked.Remove($sessionId) | Out-Null
                    continue
                }
                Stop-GoblinSession -SessionId $sessionId
                $info['Terminated'] = $true
                Write-GoblinLog "$username | GOBLIN STRIKE | $title | Played: $(Format-GoblinTime ([double]$info['PlayedSeconds']))"
            }
        }

        foreach ($sessionId in @($script:GoblinTracked.Keys)) {
            if ($seen.ContainsKey([string]$sessionId)) { continue }
            $info = $script:GoblinTracked[$sessionId]
            $script:GoblinTracked.Remove($sessionId) | Out-Null
            if ([bool]$info['Terminated']) {
                Write-GoblinLog "$($info['Username']) | Goblin scurries back into the walls | $($info['Title'])"
            }
            else {
                Write-GoblinLog "$($info['Username']) | Prey escaped before the Goblin struck | $($info['Title'])"
            }
        }

        Write-GoblinStatus
        $script:GoblinLastError = ''
        if ($null -ne $script:GoblinWorkerTimer) { $script:GoblinWorkerTimer.Interval = 2000 }
        Set-GoblinWorkerUiState
    }
    catch {
        $message = $_.Exception.Message
        Write-GoblinLog "Goblin tripped over a bucket | $($_.Exception.GetType().Name): $message"
        $script:GoblinLastError = $message
        if ($null -ne $script:GoblinWorkerTimer) { $script:GoblinWorkerTimer.Interval = 5000 }
        if ($null -ne $script:GoblinWorkerLabel) {
            $script:GoblinWorkerLabel.Text = 'Stream Goblin: tripped; retrying automatically'
            $script:GoblinWorkerLabel.ForeColor = [Drawing.Color]::FromArgb(235, 170, 80)
        }
        Write-GoblinStatus
    }
    finally { $script:GoblinPolling = $false }
}

function Start-StreamGoblinEngine {
    if (-not $script:GoblinConfigured) { return $false }
    if ($script:GoblinEngineRunning) { return $true }
    try {
        $legacyWorker = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -like '*C:\StreamGoblin\worker.py*' } |
            Select-Object -First 1
        if ($null -ne $legacyWorker) {
            [System.Windows.Forms.MessageBox]::Show(
                'The old C:\StreamGoblin\worker.py process is still running. Close its command window first so two Goblins do not attack the same stream.',
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return $false
        }
    }
    catch { }
    $script:GoblinEngineRunning = $true
    $script:GoblinTracked = @{}
    $script:GoblinWorkerTimer.Interval = 2000
    $script:GoblinWorkerTimer.Start()
    Write-GoblinLog "GOBLIN AWAKENS | Integrated worker PID $PID"
    Set-GoblinWorkerUiState
    Invoke-StreamGoblinSweep
    return $true
}

function Stop-StreamGoblinEngine {
    param([switch]$ApplicationClosing)
    if ($null -ne $script:GoblinWorkerTimer) { $script:GoblinWorkerTimer.Stop() }
    if ($script:GoblinEngineRunning) {
        if ($ApplicationClosing) { Write-GoblinLog 'GOBLIN SLEEPS | Plex Goblin closed.' }
        else { Write-GoblinLog 'GOBLIN SLEEPS | Tracking stopped by the server owner.' }
    }
    $script:GoblinEngineRunning = $false
    $script:GoblinTracked = @{}
    Write-GoblinStatus
    Set-GoblinWorkerUiState
}

function Refresh-GoblinMonitorGrid {
    if ($null -eq $script:GoblinMonitorGrid -or $script:GoblinMonitorGrid.IsDisposed) { return }
    $now = Get-GoblinMonotonicSeconds
    $script:GoblinMonitorGrid.SuspendLayout()
    try {
        $script:GoblinMonitorGrid.Rows.Clear()
        foreach ($sessionId in @($script:GoblinTracked.Keys | Sort-Object)) {
            $info = $script:GoblinTracked[$sessionId]
            $played = [double]$info['PlayedSeconds']
            if ([string]$info['LastState'] -eq 'playing' -and -not [bool]$info['Terminated']) {
                $played += [Math]::Max(0, $now - [double]$info['LastCheck'])
            }
            $goal = [double]$info['GoalSeconds']
            $remaining = [Math]::Max(0, $goal - $played)
            $percent = if ($goal -gt 0) { [int][Math]::Min(100, [Math]::Max(0, ($played / $goal) * 100)) } else { 0 }
            $state = [string]$info['LastState']
            if ([bool]$info['Terminated']) { $state = 'STRUCK' }
            elseif ($state -eq 'paused') { $state = 'PAUSED' }
            else { $state = $state.ToUpperInvariant() }
            $index = $script:GoblinMonitorGrid.Rows.Add(
                $info['Username'],
                $info['Title'],
                $state,
                (Format-GoblinTime $goal),
                (Format-GoblinTime $remaining),
                $percent,
                $sessionId,
                [bool]$info['Terminated']
            )
            if ([bool]$info['Terminated']) {
                $script:GoblinMonitorGrid.Rows[$index].DefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(78, 39, 39)
            }
            elseif ([string]$info['LastState'] -eq 'paused') {
                $script:GoblinMonitorGrid.Rows[$index].DefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(78, 62, 36)
            }
        }
    }
    finally { $script:GoblinMonitorGrid.ResumeLayout() }
}

function Set-GoblinButtonStyle {
    param($Button, [Drawing.Color]$BackColor)
    $Button.BackColor = $BackColor
    $Button.ForeColor = $script:GoblinTheme.Text
    $Button.FlatStyle = 'Flat'
    $Button.FlatAppearance.BorderColor = $script:GoblinTheme.Border
    $Button.FlatAppearance.MouseOverBackColor = $script:GoblinTheme.ButtonHover
    $Button.FlatAppearance.MouseDownBackColor = $script:GoblinTheme.Selection
    $Button.UseVisualStyleBackColor = $false
}

function Set-GoblinGridStyle {
    param($Grid)
    $Grid.AllowUserToAddRows = $false
    $Grid.AllowUserToDeleteRows = $false
    $Grid.AllowUserToResizeRows = $false
    $Grid.AutoGenerateColumns = $false
    $Grid.BackgroundColor = $script:GoblinTheme.Window
    $Grid.BorderStyle = 'FixedSingle'
    $Grid.GridColor = $script:GoblinTheme.Border
    $Grid.RowHeadersVisible = $false
    $Grid.EnableHeadersVisualStyles = $false
    $Grid.ColumnHeadersBorderStyle = 'Single'
    $Grid.ColumnHeadersDefaultCellStyle.BackColor = $script:GoblinTheme.Header
    $Grid.ColumnHeadersDefaultCellStyle.ForeColor = $script:GoblinTheme.Text
    $Grid.DefaultCellStyle.BackColor = $script:GoblinTheme.Surface
    $Grid.DefaultCellStyle.ForeColor = $script:GoblinTheme.Text
    $Grid.DefaultCellStyle.SelectionBackColor = $script:GoblinTheme.Selection
    $Grid.DefaultCellStyle.SelectionForeColor = $script:GoblinTheme.Text
    $Grid.AlternatingRowsDefaultCellStyle.BackColor = $script:GoblinTheme.AlternateRow
    $Grid.AlternatingRowsDefaultCellStyle.ForeColor = $script:GoblinTheme.Text
}

function Add-GoblinGridColumn {
    param($Grid, [string]$Name, [string]$Header, [int]$Width, [bool]$CheckBox, [bool]$ReadOnly, [bool]$Fill)
    if ($CheckBox) { $column = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn }
    else { $column = New-Object System.Windows.Forms.DataGridViewTextBoxColumn }
    $column.Name = $Name
    $column.HeaderText = $Header
    $column.Width = $Width
    $column.ReadOnly = $ReadOnly
    if ($Fill) { $column.AutoSizeMode = 'Fill' }
    $Grid.Columns.Add($column) | Out-Null
}

function Refresh-GoblinTargetGrid {
    if ($null -eq $script:GoblinTargetGrid -or $script:GoblinTargetGrid.IsDisposed) { return }
    $names = @{}
    foreach ($name in $script:GoblinTargets.Keys) { $names[[string]$name] = $true }
    foreach ($user in @($script:Users)) {
        $name = [string]$user.Username
        if (-not [string]::IsNullOrWhiteSpace($name)) { $names[$name] = $true }
    }
    $script:GoblinTargetGrid.Rows.Clear()
    foreach ($name in @($names.Keys | Sort-Object)) {
        $target = Get-GoblinTarget -Username $name
        $enabled = $false
        $minimum = 10
        $maximum = 15
        if ($null -ne $target) {
            $enabled = [bool]$target['Enabled']
            $minimum = [int]$target['MinimumMinutes']
            $maximum = [int]$target['MaximumMinutes']
        }
        $script:GoblinTargetGrid.Rows.Add($enabled, $name, $minimum, $maximum) | Out-Null
    }
}

function Save-GoblinTargetsFromGrid {
    $script:GoblinTargetGrid.EndEdit() | Out-Null
    $newTargets = @{}
    foreach ($row in $script:GoblinTargetGrid.Rows) {
        $name = ([string]$row.Cells['Username'].Value).Trim()
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        try {
            $minimum = [int]$row.Cells['Minimum'].Value
            $maximum = [int]$row.Cells['Maximum'].Value
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                "$name needs whole numbers for minimum and maximum minutes.",
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return $false
        }
        if ($minimum -lt 1 -or $maximum -lt $minimum -or $maximum -gt 10080) {
            [System.Windows.Forms.MessageBox]::Show(
                "$name needs a range from 1 to 10,080 minutes, with maximum at least minimum.",
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return $false
        }
        $newTargets[$name] = @{
            Enabled = [bool]$row.Cells['Enabled'].Value
            MinimumMinutes = $minimum
            MaximumMinutes = $maximum
        }
    }
    $message = $script:GoblinErrorBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($message)) { $message = 'Playback error. Please try again.' }
    if ($message.Length -gt 500) {
        [System.Windows.Forms.MessageBox]::Show(
            'The playback message must be 500 characters or fewer.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return $false
    }
    $oldTargets = $script:GoblinTargets
    $oldMessage = $script:GoblinErrorMessage
    $script:GoblinTargets = $newTargets
    $script:GoblinErrorMessage = $message
    try { Save-GoblinConfiguration }
    catch {
        $script:GoblinTargets = $oldTargets
        $script:GoblinErrorMessage = $oldMessage
        [System.Windows.Forms.MessageBox]::Show(
            "Could not save Stream Goblin settings. The prior settings remain active.`r`n`r`n$($_.Exception.Message)",
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return $false
    }
    Set-GoblinWorkerUiState
    Write-GoblinLog 'Goblin target settings saved. Fresh dice are ready for every new playback.'
    return $true
}

function Show-GoblinTimeDialog {
    param(
        [Parameter(Mandatory = $true)][string]$Username,
        [Parameter(Mandatory = $true)][int]$MinimumMinutes,
        [Parameter(Mandatory = $true)][int]$MaximumMinutes
    )

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Change Stream Goblin Times'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.ClientSize = New-Object System.Drawing.Size(450, 268)
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowInTaskbar = $false
    $dialog.BackColor = $script:GoblinTheme.Window
    $dialog.ForeColor = $script:GoblinTheme.Text
    $dialog.Font = $script:GoblinParentForm.Font
    $dialogIconPath = Join-Path $PSScriptRoot 'PlexGoblin.ico'
    if (Test-Path -LiteralPath $dialogIconPath) {
        $dialog.Icon = New-Object System.Drawing.Icon($dialogIconPath)
    }

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Random playback timer for $Username"
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(18, 17)
    $title.Size = New-Object System.Drawing.Size(412, 27)
    $dialog.Controls.Add($title)

    $explanation = New-Object System.Windows.Forms.Label
    $explanation.Text = 'Every new playback gets an inclusive random roll between these values. Only actual playing time counts.'
    $explanation.Location = New-Object System.Drawing.Point(20, 50)
    $explanation.Size = New-Object System.Drawing.Size(410, 42)
    $explanation.ForeColor = $script:GoblinTheme.MutedText
    $dialog.Controls.Add($explanation)

    $minimumLabel = New-Object System.Windows.Forms.Label
    $minimumLabel.Text = 'Minimum minutes:'
    $minimumLabel.AutoSize = $true
    $minimumLabel.Location = New-Object System.Drawing.Point(20, 111)
    $dialog.Controls.Add($minimumLabel)

    $minimumBox = New-Object System.Windows.Forms.NumericUpDown
    $minimumBox.Location = New-Object System.Drawing.Point(165, 107)
    $minimumBox.Size = New-Object System.Drawing.Size(115, 25)
    $minimumBox.Minimum = 1
    $minimumBox.Maximum = 10080
    $minimumBox.Value = [Math]::Min(10080, [Math]::Max(1, $MinimumMinutes))
    $minimumBox.BackColor = $script:GoblinTheme.Surface
    $minimumBox.ForeColor = $script:GoblinTheme.Text
    $minimumBox.BorderStyle = 'FixedSingle'
    $dialog.Controls.Add($minimumBox)

    $maximumLabel = New-Object System.Windows.Forms.Label
    $maximumLabel.Text = 'Maximum minutes:'
    $maximumLabel.AutoSize = $true
    $maximumLabel.Location = New-Object System.Drawing.Point(20, 153)
    $dialog.Controls.Add($maximumLabel)

    $maximumBox = New-Object System.Windows.Forms.NumericUpDown
    $maximumBox.Location = New-Object System.Drawing.Point(165, 149)
    $maximumBox.Size = New-Object System.Drawing.Size(115, 25)
    $maximumBox.Minimum = 1
    $maximumBox.Maximum = 10080
    $maximumBox.Value = [Math]::Min(10080, [Math]::Max(1, $MaximumMinutes))
    $maximumBox.BackColor = $script:GoblinTheme.Surface
    $maximumBox.ForeColor = $script:GoblinTheme.Text
    $maximumBox.BorderStyle = 'FixedSingle'
    $dialog.Controls.Add($maximumBox)

    $limit = New-Object System.Windows.Forms.Label
    $limit.Text = 'Allowed range: 1 minute to 7 days.'
    $limit.AutoSize = $true
    $limit.Location = New-Object System.Drawing.Point(20, 192)
    $limit.ForeColor = $script:GoblinTheme.MutedText
    $dialog.Controls.Add($limit)

    $save = New-Object System.Windows.Forms.Button
    $save.Text = 'Save Time Range'
    $save.Location = New-Object System.Drawing.Point(235, 220)
    $save.Size = New-Object System.Drawing.Size(120, 32)
    Set-GoblinButtonStyle -Button $save -BackColor $script:GoblinTheme.Success
    $dialog.Controls.Add($save)

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.Location = New-Object System.Drawing.Point(365, 220)
    $cancel.Size = New-Object System.Drawing.Size(65, 32)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    Set-GoblinButtonStyle -Button $cancel -BackColor $script:GoblinTheme.Button
    $dialog.Controls.Add($cancel)
    $dialog.CancelButton = $cancel

    Set-GoblinCompactDialog -Dialog $dialog -Fields @($title, $explanation, $minimumLabel, $minimumBox, $maximumLabel, $maximumBox, $limit) -Buttons @($save, $cancel)

    $save.Add_Click({
        $minimum = [int]$minimumBox.Value
        $maximum = [int]$maximumBox.Value
        if ($maximum -lt $minimum) {
            [System.Windows.Forms.MessageBox]::Show(
                'Maximum minutes cannot be lower than minimum minutes.',
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return
        }
        $dialog.Tag = [PSCustomObject]@{
            MinimumMinutes = $minimum
            MaximumMinutes = $maximum
        }
        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })

    $dialog.AcceptButton = $save
    if ($dialog.ShowDialog($script:GoblinParentForm) -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    return $dialog.Tag
}

function Edit-SelectedGoblinTimeRange {
    $row = $script:GoblinTargetGrid.CurrentRow
    if ($null -eq $row) {
        [System.Windows.Forms.MessageBox]::Show(
            'Select a Stream Goblin user first.',
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $username = [string]$row.Cells['Username'].Value
    $oldMinimum = [int]$row.Cells['Minimum'].Value
    $oldMaximum = [int]$row.Cells['Maximum'].Value
    $result = Show-GoblinTimeDialog -Username $username -MinimumMinutes $oldMinimum -MaximumMinutes $oldMaximum
    if ($null -eq $result) { return }

    $row.Cells['Minimum'].Value = [int]$result.MinimumMinutes
    $row.Cells['Maximum'].Value = [int]$result.MaximumMinutes
    if (Save-GoblinTargetsFromGrid) {
        Refresh-GoblinTargetGrid
        foreach ($candidate in $script:GoblinTargetGrid.Rows) {
            if ([string]$candidate.Cells['Username'].Value -ieq $username) {
                $script:GoblinTargetGrid.CurrentCell = $candidate.Cells['Minimum']
                break
            }
        }
    }
    else {
        $row.Cells['Minimum'].Value = $oldMinimum
        $row.Cells['Maximum'].Value = $oldMaximum
    }
}

function Show-AddGoblinUserDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Add Stream Goblin Username'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.ClientSize = New-Object System.Drawing.Size(420, 145)
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.BackColor = $script:GoblinTheme.Window
    $dialog.ForeColor = $script:GoblinTheme.Text
    $dialog.Font = $script:GoblinParentForm.Font
    $label = New-Object System.Windows.Forms.Label
    $label.Text = 'Tautulli/Plex username:'
    $label.AutoSize = $true
    $label.Location = New-Object System.Drawing.Point(18, 18)
    $dialog.Controls.Add($label)
    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = New-Object System.Drawing.Point(20, 48)
    $box.Size = New-Object System.Drawing.Size(378, 25)
    $box.MaxLength = 128
    $box.BackColor = $script:GoblinTheme.Surface
    $box.ForeColor = $script:GoblinTheme.Text
    $dialog.Controls.Add($box)
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = 'Add'
    $ok.Location = New-Object System.Drawing.Point(220, 94)
    $ok.Size = New-Object System.Drawing.Size(84, 30)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    Set-GoblinButtonStyle -Button $ok -BackColor $script:GoblinTheme.Success
    $dialog.Controls.Add($ok)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.Location = New-Object System.Drawing.Point(314, 94)
    $cancel.Size = New-Object System.Drawing.Size(84, 30)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    Set-GoblinButtonStyle -Button $cancel -BackColor $script:GoblinTheme.Button
    $dialog.Controls.Add($cancel)
    $dialog.AcceptButton = $ok
    $dialog.CancelButton = $cancel
    Set-GoblinCompactDialog -Dialog $dialog -Fields @($label, $box) -Buttons @($ok, $cancel)
    if ($dialog.ShowDialog($script:GoblinParentForm) -ne [System.Windows.Forms.DialogResult]::OK) { return '' }
    return $box.Text.Trim()
}

function Show-GoblinConnectionDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Configure Tautulli'
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.ClientSize = New-Object System.Drawing.Size(570, 285)
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.BackColor = $script:GoblinTheme.Window
    $dialog.ForeColor = $script:GoblinTheme.Text
    $dialog.Font = $script:GoblinParentForm.Font

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Local Tautulli connection'
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(18, 16)
    $dialog.Controls.Add($title)
    $help = New-Object System.Windows.Forms.Label
    $help.Text = 'The API key is encrypted for this Windows account. Leave it blank to keep the currently saved key.'
    $help.Location = New-Object System.Drawing.Point(20, 48)
    $help.Size = New-Object System.Drawing.Size(525, 38)
    $help.ForeColor = $script:GoblinTheme.MutedText
    $dialog.Controls.Add($help)

    $urlLabel = New-Object System.Windows.Forms.Label
    $urlLabel.Text = 'Tautulli URL:'
    $urlLabel.AutoSize = $true
    $urlLabel.Location = New-Object System.Drawing.Point(20, 95)
    $dialog.Controls.Add($urlLabel)
    $urlBox = New-Object System.Windows.Forms.TextBox
    $urlBox.Text = $script:GoblinTautulliUrl
    $urlBox.Location = New-Object System.Drawing.Point(120, 91)
    $urlBox.Size = New-Object System.Drawing.Size(425, 25)
    $urlBox.BackColor = $script:GoblinTheme.Surface
    $urlBox.ForeColor = $script:GoblinTheme.Text
    $dialog.Controls.Add($urlBox)

    $keyLabel = New-Object System.Windows.Forms.Label
    $keyLabel.Text = 'API key:'
    $keyLabel.AutoSize = $true
    $keyLabel.Location = New-Object System.Drawing.Point(20, 137)
    $dialog.Controls.Add($keyLabel)
    $keyBox = New-Object System.Windows.Forms.TextBox
    $keyBox.Location = New-Object System.Drawing.Point(120, 133)
    $keyBox.Size = New-Object System.Drawing.Size(425, 25)
    $keyBox.UseSystemPasswordChar = $true
    $keyBox.BackColor = $script:GoblinTheme.Surface
    $keyBox.ForeColor = $script:GoblinTheme.Text
    $dialog.Controls.Add($keyBox)
    $show = New-Object System.Windows.Forms.CheckBox
    $show.Text = 'Show API key'
    $show.AutoSize = $true
    $show.Location = New-Object System.Drawing.Point(120, 169)
    $show.Add_CheckedChanged({ $keyBox.UseSystemPasswordChar = -not $show.Checked })
    $dialog.Controls.Add($show)

    $save = New-Object System.Windows.Forms.Button
    $save.Text = 'Test && Save'
    $save.Location = New-Object System.Drawing.Point(355, 230)
    $save.Size = New-Object System.Drawing.Size(96, 32)
    Set-GoblinButtonStyle -Button $save -BackColor $script:GoblinTheme.Success
    $dialog.Controls.Add($save)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.Location = New-Object System.Drawing.Point(461, 230)
    $cancel.Size = New-Object System.Drawing.Size(84, 32)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    Set-GoblinButtonStyle -Button $cancel -BackColor $script:GoblinTheme.Button
    $dialog.Controls.Add($cancel)
    $dialog.CancelButton = $cancel

    Set-GoblinCompactDialog -Dialog $dialog -Fields @($title, $help, $urlLabel, $urlBox, $keyLabel, $keyBox, $show) -Buttons @($save, $cancel)

    $save.Add_Click({
        $newUrl = $urlBox.Text.Trim().TrimEnd('/')
        $newKey = $keyBox.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($newKey)) { $newKey = $script:GoblinApiKey }
        if (-not (Test-GoblinTautulliUrl -Url $newUrl)) {
            [System.Windows.Forms.MessageBox]::Show(
                'Use a local Tautulli URL such as http://127.0.0.1:8181.',
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return
        }
        if ([string]::IsNullOrWhiteSpace($newKey)) {
            [System.Windows.Forms.MessageBox]::Show(
                'Enter the Tautulli API key.',
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return
        }
        $oldUrl = $script:GoblinTautulliUrl
        $oldKey = $script:GoblinApiKey
        $oldConfigured = $script:GoblinConfigured
        $script:GoblinTautulliUrl = $newUrl
        $script:GoblinApiKey = $newKey
        try {
            Invoke-GoblinApi -Command 'get_activity' | Out-Null
        }
        catch {
            $script:GoblinTautulliUrl = $oldUrl
            $script:GoblinApiKey = $oldKey
            [System.Windows.Forms.MessageBox]::Show(
                "Tautulli connection failed.`r`n`r`n$($_.Exception.Message)",
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            return
        }
        try {
            Protect-GoblinApiKey -ApiKey $newKey
            $script:GoblinConfigured = $true
            Save-GoblinConfiguration
            Write-GoblinLog 'Tautulli connection tested. Goblin found the tunnel.'
            $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dialog.Close()
        }
        catch {
            $script:GoblinTautulliUrl = $oldUrl
            $script:GoblinApiKey = $oldKey
            $script:GoblinConfigured = $oldConfigured
            [System.Windows.Forms.MessageBox]::Show(
                "Tautulli connected successfully, but Plex Goblin could not save the local connection settings.`r`n`r`n$($_.Exception.Message)",
                $script:AppName,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    })

    return ($dialog.ShowDialog($script:GoblinParentForm) -eq [System.Windows.Forms.DialogResult]::OK)
}

function Load-GoblinRecentLog {
    if ($null -eq $script:GoblinLogBox) { return }
    $script:GoblinLogBox.Clear()
    $path = Get-GoblinDailyLogPath
    try {
        $lines = @(Get-Content -LiteralPath $path -Encoding UTF8 -ErrorAction Stop | Select-Object -Last 100)
        if ($lines.Count -gt 0) { $script:GoblinLogBox.Text = ($lines -join "`r`n") + "`r`n" }
        $script:GoblinLogBox.SelectionStart = $script:GoblinLogBox.TextLength
        $script:GoblinLogBox.ScrollToCaret()
    }
    catch { }
}

# Shared layout primitives use preferred sizes for text and a flexible body row.
function New-GoblinLayout {
    param([string[]]$Rows)
    $panel = New-Object System.Windows.Forms.TableLayoutPanel
    $panel.Dock = 'Fill'
    $panel.ColumnCount = 1
    $panel.RowCount = $Rows.Count
    $panel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100))) | Out-Null
    foreach ($row in $Rows) {
        $style = New-Object System.Windows.Forms.RowStyle
        if ($row -eq 'Fill') { $style.SizeType = 'Percent'; $style.Height = 100 }
        else { $style.SizeType = 'AutoSize' }
        $panel.RowStyles.Add($style) | Out-Null
    }
    return $panel
}

function Set-GoblinCompactDialog {
    param($Dialog, [object[]]$Fields, [object[]]$Buttons)
    $area = [System.Windows.Forms.Screen]::FromControl($Dialog).WorkingArea
    $width = [Math]::Min(380, $area.Width - 40)
    $Dialog.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $Dialog.BackColor = [Drawing.Color]::FromArgb(22, 24, 28)
    $Dialog.ForeColor = [Drawing.Color]::FromArgb(235, 237, 240)
    $Dialog.AutoScroll = $true
    $Dialog.ClientSize = New-Object System.Drawing.Size($width, 400)
    $rows = @()
    foreach ($field in $Fields) { $rows += 'Auto' }
    $rows += 'Auto'
    $layout = New-GoblinLayout -Rows $rows
    $layout.Dock = 'Top'
    $layout.AutoSize = $true
    $layout.Padding = New-Object System.Windows.Forms.Padding(12)
    $index = 0
    foreach ($field in $Fields) {
        $field.Dock = 'Fill'
        $field.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 4)
        if ($field -is [System.Windows.Forms.Label]) {
            $field.AutoSize = $true
            $field.MaximumSize = New-Object System.Drawing.Size(($width - 40), 0)
        }
        if ($field -is [System.Windows.Forms.TextBox] -or $field -is [System.Windows.Forms.NumericUpDown]) {
            $field.BackColor = [Drawing.Color]::FromArgb(30, 33, 38)
            $field.ForeColor = $Dialog.ForeColor
        }
        $layout.Controls.Add($field, 0, $index)
        $index++
    }
    $actions = New-GoblinFlow
    foreach ($button in $Buttons) {
        $button.AutoSize = $true
        $button.AutoSizeMode = 'GrowAndShrink'
        $button.MinimumSize = New-Object System.Drawing.Size(85, 40)
        $button.BackColor = [Drawing.Color]::FromArgb(53, 57, 63)
        $button.ForeColor = $Dialog.ForeColor
        $button.FlatStyle = 'Flat'
        $actions.Controls.Add($button)
    }
    $layout.Controls.Add($actions, 0, $index)
    $Dialog.Controls.Add($layout)
    $layout.PerformLayout()
    $height = $layout.GetPreferredSize((New-Object System.Drawing.Size($width, 0))).Height
    $Dialog.ClientSize = New-Object System.Drawing.Size($width, ([Math]::Min($area.Height - 80, $height + 8)))
}

function New-GoblinFlow {
    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.AutoSize = $true
    $panel.AutoSizeMode = 'GrowAndShrink'
    $panel.WrapContents = $true
    $panel.Dock = 'Fill'
    $panel.Margin = New-Object System.Windows.Forms.Padding(0)
    return $panel
}

function Initialize-StreamGoblinUi {
    param(
        [Parameter(Mandatory = $true)]$TabPage,
        [Parameter(Mandatory = $true)][hashtable]$Theme,
        [Parameter(Mandatory = $true)]$ParentForm
    )
    $script:GoblinTheme = $Theme
    $script:GoblinParentForm = $ParentForm
    $TabPage.BackColor = $Theme.Window
    $TabPage.ForeColor = $Theme.Text

    $header = New-Object System.Windows.Forms.Label
    $header.Text = 'Stream Goblin + Monitor Goblin'
    $header.Font = New-Object System.Drawing.Font('Segoe UI', 14, [Drawing.FontStyle]::Bold)
    $header.AutoSize = $true
    $header.Location = New-Object System.Drawing.Point(18, 14)
    $TabPage.Controls.Add($header)

    $script:GoblinConnectionLabel = New-Object System.Windows.Forms.Label
    $script:GoblinConnectionLabel.Text = 'Tautulli: loading...'
    $script:GoblinConnectionLabel.AutoSize = $true
    $script:GoblinConnectionLabel.Location = New-Object System.Drawing.Point(21, 49)
    $TabPage.Controls.Add($script:GoblinConnectionLabel)
    $script:GoblinWorkerLabel = New-Object System.Windows.Forms.Label
    $script:GoblinWorkerLabel.Text = 'Stream Goblin: sleeping'
    $script:GoblinWorkerLabel.AutoSize = $true
    $script:GoblinWorkerLabel.Location = New-Object System.Drawing.Point(270, 49)
    $TabPage.Controls.Add($script:GoblinWorkerLabel)

    $configureButton = New-Object System.Windows.Forms.Button
    $configureButton.Text = 'Configure Tautulli'
    $configureButton.Location = New-Object System.Drawing.Point(674, 38)
    $configureButton.Size = New-Object System.Drawing.Size(130, 31)
    Set-GoblinButtonStyle -Button $configureButton -BackColor $Theme.Button
    $TabPage.Controls.Add($configureButton)
    $script:GoblinToggleButton = New-Object System.Windows.Forms.Button
    $script:GoblinToggleButton.Text = 'Start Stream Goblin'
    $script:GoblinToggleButton.Location = New-Object System.Drawing.Point(814, 38)
    $script:GoblinToggleButton.Size = New-Object System.Drawing.Size(145, 31)
    Set-GoblinButtonStyle -Button $script:GoblinToggleButton -BackColor $Theme.Success
    $TabPage.Controls.Add($script:GoblinToggleButton)
    $openLogsButton = New-Object System.Windows.Forms.Button
    $openLogsButton.Text = 'Open Logs'
    $openLogsButton.Location = New-Object System.Drawing.Point(969, 38)
    $openLogsButton.Size = New-Object System.Drawing.Size(90, 31)
    Set-GoblinButtonStyle -Button $openLogsButton -BackColor $Theme.Button
    $TabPage.Controls.Add($openLogsButton)

    $targetsLabel = New-Object System.Windows.Forms.Label
    $targetsLabel.Text = 'Targets - fresh random roll per playback'
    $targetsLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
    $targetsLabel.AutoSize = $true
    $targetsLabel.Location = New-Object System.Drawing.Point(20, 82)
    $TabPage.Controls.Add($targetsLabel)

    $changeTimesButton = New-Object System.Windows.Forms.Button
    $changeTimesButton.Text = 'Change Times...'
    $changeTimesButton.Location = New-Object System.Drawing.Point(332, 75)
    $changeTimesButton.Size = New-Object System.Drawing.Size(125, 28)
    Set-GoblinButtonStyle -Button $changeTimesButton -BackColor $Theme.Button
    $TabPage.Controls.Add($changeTimesButton)

    $script:GoblinTargetGrid = New-Object System.Windows.Forms.DataGridView
    $script:GoblinTargetGrid.Location = New-Object System.Drawing.Point(22, 108)
    $script:GoblinTargetGrid.Size = New-Object System.Drawing.Size(435, 250)
    $script:GoblinTargetGrid.SelectionMode = 'FullRowSelect'
    $script:GoblinTargetGrid.EditMode = 'EditOnEnter'
    Set-GoblinGridStyle -Grid $script:GoblinTargetGrid
    Add-GoblinGridColumn -Grid $script:GoblinTargetGrid -Name 'Enabled' -Header 'Enable' -Width 55 -CheckBox $true -ReadOnly $false -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinTargetGrid -Name 'Username' -Header 'Plex user' -Width 160 -CheckBox $false -ReadOnly $true -Fill $true
    Add-GoblinGridColumn -Grid $script:GoblinTargetGrid -Name 'Minimum' -Header 'Min (minutes)' -Width 80 -CheckBox $false -ReadOnly $false -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinTargetGrid -Name 'Maximum' -Header 'Max (minutes)' -Width 80 -CheckBox $false -ReadOnly $false -Fill $false
    $script:GoblinTargetGrid.Columns['Minimum'].DefaultCellStyle.BackColor = $Theme.Header
    $script:GoblinTargetGrid.Columns['Maximum'].DefaultCellStyle.BackColor = $Theme.Header
    $TabPage.Controls.Add($script:GoblinTargetGrid)

    $messageLabel = New-Object System.Windows.Forms.Label
    $messageLabel.Text = 'Playback message shown when the Goblin strikes:'
    $messageLabel.AutoSize = $true
    $messageLabel.Location = New-Object System.Drawing.Point(20, 370)
    $TabPage.Controls.Add($messageLabel)
    $script:GoblinErrorBox = New-Object System.Windows.Forms.TextBox
    $script:GoblinErrorBox.Location = New-Object System.Drawing.Point(22, 394)
    $script:GoblinErrorBox.Size = New-Object System.Drawing.Size(435, 25)
    $script:GoblinErrorBox.MaxLength = 500
    $script:GoblinErrorBox.BackColor = $Theme.Surface
    $script:GoblinErrorBox.ForeColor = $Theme.Text
    $TabPage.Controls.Add($script:GoblinErrorBox)

    $saveTargetsButton = New-Object System.Windows.Forms.Button
    $saveTargetsButton.Text = 'Save Target Settings'
    $saveTargetsButton.Location = New-Object System.Drawing.Point(22, 433)
    $saveTargetsButton.Size = New-Object System.Drawing.Size(140, 31)
    Set-GoblinButtonStyle -Button $saveTargetsButton -BackColor $Theme.Success
    $TabPage.Controls.Add($saveTargetsButton)
    $disableAllButton = New-Object System.Windows.Forms.Button
    $disableAllButton.Text = 'Disable All'
    $disableAllButton.Location = New-Object System.Drawing.Point(172, 433)
    $disableAllButton.Size = New-Object System.Drawing.Size(100, 31)
    Set-GoblinButtonStyle -Button $disableAllButton -BackColor $Theme.Button
    $TabPage.Controls.Add($disableAllButton)
    $addUserButton = New-Object System.Windows.Forms.Button
    $addUserButton.Text = 'Add Username...'
    $addUserButton.Location = New-Object System.Drawing.Point(282, 433)
    $addUserButton.Size = New-Object System.Drawing.Size(125, 31)
    Set-GoblinButtonStyle -Button $addUserButton -BackColor $Theme.Button
    $TabPage.Controls.Add($addUserButton)

    $help = New-Object System.Windows.Forms.Label
    $help.Text = "Check Enable, then click Save Target Settings. Only PLAYING time counts.`r`nPausing freezes the countdown; changing media rerolls it.`r`nThe User Access tab takes priority if that user is blocked there."
    $help.Location = New-Object System.Drawing.Point(22, 480)
    $help.Size = New-Object System.Drawing.Size(435, 58)
    $help.ForeColor = $Theme.MutedText
    $TabPage.Controls.Add($help)

    $monitorLabel = New-Object System.Windows.Forms.Label
    $monitorLabel.Text = 'Monitor Goblin - live countdowns'
    $monitorLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
    $monitorLabel.AutoSize = $true
    $monitorLabel.Location = New-Object System.Drawing.Point(482, 82)
    $TabPage.Controls.Add($monitorLabel)

    $script:GoblinMonitorGrid = New-Object System.Windows.Forms.DataGridView
    $script:GoblinMonitorGrid.Location = New-Object System.Drawing.Point(484, 108)
    $script:GoblinMonitorGrid.Size = New-Object System.Drawing.Size(575, 250)
    $script:GoblinMonitorGrid.ReadOnly = $true
    $script:GoblinMonitorGrid.SelectionMode = 'FullRowSelect'
    Set-GoblinGridStyle -Grid $script:GoblinMonitorGrid
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Username' -Header 'User' -Width 90 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Title' -Header 'Playing' -Width 150 -CheckBox $false -ReadOnly $true -Fill $true
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'State' -Header 'State' -Width 65 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Roll' -Header 'Roll' -Width 58 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Countdown' -Header 'Left' -Width 58 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Progress' -Header 'Countdown bar' -Width 120 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'SessionId' -Header 'Session' -Width 20 -CheckBox $false -ReadOnly $true -Fill $false
    Add-GoblinGridColumn -Grid $script:GoblinMonitorGrid -Name 'Terminated' -Header 'Terminated' -Width 20 -CheckBox $false -ReadOnly $true -Fill $false
    $script:GoblinMonitorGrid.Columns['SessionId'].Visible = $false
    $script:GoblinMonitorGrid.Columns['Terminated'].Visible = $false
    $TabPage.Controls.Add($script:GoblinMonitorGrid)

    $script:GoblinMonitorGrid.Add_CellPainting({
        param($sender, $eventArgs)
        if ($eventArgs.RowIndex -lt 0 -or $sender.Columns[$eventArgs.ColumnIndex].Name -ne 'Progress') { return }
        $eventArgs.PaintBackground($eventArgs.CellBounds, $true)
        $percent = 0
        if ($null -ne $eventArgs.Value) { $percent = [int]$eventArgs.Value }
        $percent = [int][Math]::Min(100, [Math]::Max(0, $percent))
        $rect = $eventArgs.CellBounds
        $rect.Inflate(-4, -6)
        $fillWidth = [int][Math]::Floor($rect.Width * ($percent / 100.0))
        $terminated = [bool]$sender.Rows[$eventArgs.RowIndex].Cells['Terminated'].Value
        $fillColor = if ($terminated) { [Drawing.Color]::FromArgb(180, 70, 70) } else { [Drawing.Color]::FromArgb(76, 175, 100) }
        $fillBrush = New-Object Drawing.SolidBrush($fillColor)
        $borderPen = New-Object Drawing.Pen($script:GoblinTheme.Border)
        try {
            if ($fillWidth -gt 0) { $eventArgs.Graphics.FillRectangle($fillBrush, $rect.X, $rect.Y, $fillWidth, $rect.Height) }
            $eventArgs.Graphics.DrawRectangle($borderPen, $rect)
            [System.Windows.Forms.TextRenderer]::DrawText(
                $eventArgs.Graphics,
                "$percent%",
                $sender.Font,
                $eventArgs.CellBounds,
                $script:GoblinTheme.Text,
                [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter
            )
        }
        finally {
            $fillBrush.Dispose()
            $borderPen.Dispose()
        }
        $eventArgs.Handled = $true
    })

    $logLabel = New-Object System.Windows.Forms.Label
    $logLabel.Text = 'Goblin activity - recent funny notifications and today''s log'
    $logLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
    $logLabel.AutoSize = $true
    $logLabel.Location = New-Object System.Drawing.Point(482, 370)
    $TabPage.Controls.Add($logLabel)
    $script:GoblinLogBox = New-Object System.Windows.Forms.RichTextBox
    $script:GoblinLogBox.Location = New-Object System.Drawing.Point(484, 394)
    $script:GoblinLogBox.Size = New-Object System.Drawing.Size(575, 205)
    $script:GoblinLogBox.ReadOnly = $true
    $script:GoblinLogBox.BackColor = [Drawing.Color]::FromArgb(20, 22, 25)
    $script:GoblinLogBox.ForeColor = $Theme.Text
    $script:GoblinLogBox.BorderStyle = 'FixedSingle'
    $script:GoblinLogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
    $TabPage.Controls.Add($script:GoblinLogBox)

    $configureButton.Text = 'Connection...'
    $shell = New-GoblinLayout -Rows @('Auto', 'Auto', 'Auto', 'Fill')
    $shell.Padding = New-Object System.Windows.Forms.Padding(12)
    $header.Text = 'Stream Goblin'
    $header.Font = New-Object System.Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
    $shell.Controls.Add($header, 0, 0)
    $status = New-GoblinFlow
    foreach ($label in @($script:GoblinConnectionLabel, $script:GoblinWorkerLabel)) {
        $label.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 4)
        $status.Controls.Add($label)
    }
    $shell.Controls.Add($status, 0, 1)
    $toolbar = New-GoblinFlow
    foreach ($button in @($configureButton, $script:GoblinToggleButton, $openLogsButton)) {
        $button.AutoSize = $true
        $button.AutoSizeMode = 'GrowAndShrink'
        $button.MinimumSize = New-Object System.Drawing.Size(0, 40)
        $button.Height = 40
        $button.Margin = New-Object System.Windows.Forms.Padding(0, 3, 6, 6)
        $toolbar.Controls.Add($button)
    }
    $shell.Controls.Add($toolbar, 0, 2)

    $targets = New-GoblinLayout -Rows @('Auto', 'Fill', 'Auto', 'Auto', 'Auto', 'Auto')
    $targetsLabel.Text = 'Targets / playback minutes'
    $targets.Controls.Add($targetsLabel, 0, 0)
    $targets.Controls.Add($script:GoblinTargetGrid, 0, 1)
    $messageLabel.Text = 'Playback stop message'
    $targets.Controls.Add($messageLabel, 0, 2)
    $targets.Controls.Add($script:GoblinErrorBox, 0, 3)
    $targetToolbar = New-GoblinFlow
    foreach ($button in @($saveTargetsButton, $changeTimesButton, $disableAllButton, $addUserButton)) {
        $button.AutoSize = $true
        $button.AutoSizeMode = 'GrowAndShrink'
        $button.MinimumSize = New-Object System.Drawing.Size(0, 40)
        $button.Height = 40
        $button.Margin = New-Object System.Windows.Forms.Padding(0, 3, 6, 3)
        $targetToolbar.Controls.Add($button)
    }
    $targets.Controls.Add($targetToolbar, 0, 4)
    $help.Text = 'Enable + Save to apply. Playing time counts; pauses freeze it. New media rerolls. User Access takes priority.'
    $help.AutoSize = $true
    $targets.Controls.Add($help, 0, 5)
    $script:GoblinUiTips.SetToolTip($targetsLabel, $help.Text)
    $monitor = New-GoblinLayout -Rows @('Auto', 'Fill')
    $monitorLabel.Text = 'Live sessions / countdowns'
    $monitor.Controls.Add($monitorLabel, 0, 0)
    $monitor.Controls.Add($script:GoblinMonitorGrid, 0, 1)
    $logs = New-GoblinLayout -Rows @('Auto', 'Fill')
    $logLabel.Text = 'Recent activity'
    $logs.Controls.Add($logLabel, 0, 0)
    $logs.Controls.Add($script:GoblinLogBox, 0, 1)
    foreach ($panel in @($targets, $monitor, $logs)) {
        $panel.Padding = New-Object System.Windows.Forms.Padding(6)
        foreach ($control in $panel.Controls) { $control.Dock = 'Fill' }
    }
    foreach ($g in @($script:GoblinTargetGrid, $script:GoblinMonitorGrid)) {
        $g.RowTemplate.Height = 36
        $g.ColumnHeadersHeight = 36
    }
    $script:GoblinTargetGrid.Columns['Minimum'].HeaderText = 'Min (m)'
    $script:GoblinTargetGrid.Columns['Maximum'].HeaderText = 'Max (m)'
    $script:GoblinTargetGrid.Columns['Minimum'].Width = 70
    $script:GoblinTargetGrid.Columns['Maximum'].Width = 70
    $script:GoblinTargetGrid.Columns['Username'].MinimumWidth = 95
    $script:GoblinMonitorGrid.Columns['Username'].Width = 75
    $script:GoblinMonitorGrid.Columns['State'].Width = 60
    $script:GoblinMonitorGrid.Columns['Roll'].Width = 48
    $script:GoblinMonitorGrid.Columns['Countdown'].Width = 48
    $script:GoblinMonitorGrid.Columns['Progress'].Width = 80
    $script:GoblinMonitorGrid.Columns['Title'].MinimumWidth = 100

    $monitorMinimums = @{ Username = 50; Title = 65; State = 45; Roll = 35; Countdown = 38; Progress = 50 }
    foreach ($name in $monitorMinimums.Keys) {
        $column = $script:GoblinMonitorGrid.Columns[$name]
        $column.FillWeight = $column.Width
        $column.MinimumWidth = $monitorMinimums[$name]
        $column.AutoSizeMode = 'Fill'
    }

    # Reuse the same controls when changing modes: edits, selection and logs survive.
    $compactViews = New-Object System.Windows.Forms.TabControl
    $compactViews.Dock = 'Fill'
    $compactViews.ItemSize = New-Object System.Drawing.Size(110, 36)
    $compactViews.SizeMode = 'Fixed'
    foreach ($name in @('Targets', 'Monitor', 'Activity')) {
        $page = New-Object System.Windows.Forms.TabPage
        $page.Text = $name
        $page.BackColor = $Theme.Window
        $page.ForeColor = $Theme.Text
        $compactViews.TabPages.Add($page) | Out-Null
    }
    $wideViews = New-Object System.Windows.Forms.TableLayoutPanel
    $wideViews.Dock = 'Fill'
    $wideViews.ColumnCount = 2
    $wideViews.RowCount = 1
    $wideViews.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 44))) | Out-Null
    $wideViews.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 56))) | Out-Null
    $wideViews.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100))) | Out-Null
    $right = New-Object System.Windows.Forms.TableLayoutPanel
    $right.Dock = 'Fill'
    $right.ColumnCount = 1
    $right.RowCount = 2
    $right.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100))) | Out-Null
    $right.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 62))) | Out-Null
    $right.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 38))) | Out-Null
    $wideViews.Controls.Add($right, 1, 0)
    $body = New-Object System.Windows.Forms.Panel
    $body.Dock = 'Fill'
    $body.Controls.Add($wideViews)
    $body.Controls.Add($compactViews)
    $shell.Controls.Add($body, 0, 3)
    foreach ($control in $shell.Controls) { $control.Dock = 'Fill' }
    $TabPage.Controls.Add($shell)
    $layoutState = @{ Wide = $null }
    $resizeLayout = {
        $wide = ($TabPage.ClientSize.Width / ($ParentForm.Font.Size / 10.0)) -ge 950
        if ($layoutState.Wide -eq $wide) { return }
        $body.SuspendLayout()
        try {
            if ($wide) {
                $wideViews.Controls.Add($targets, 0, 0)
                $right.Controls.Add($monitor, 0, 0)
                $right.Controls.Add($logs, 0, 1)
            }
            else {
                $compactViews.TabPages[0].Controls.Add($targets)
                $compactViews.TabPages[1].Controls.Add($monitor)
                $compactViews.TabPages[2].Controls.Add($logs)
            }
            $help.Visible = $wide
            $wideViews.Visible = $wide
            $compactViews.Visible = -not $wide
            $layoutState.Wide = $wide
        }
        finally { $body.ResumeLayout($true) }
    }.GetNewClosure()
    $TabPage.Add_Resize($resizeLayout)
    & $resizeLayout

    $script:GoblinWorkerTimer = New-Object System.Windows.Forms.Timer
    $script:GoblinWorkerTimer.Interval = 2000
    $script:GoblinWorkerTimer.Add_Tick({ Invoke-StreamGoblinSweep })
    $script:GoblinUiTimer = New-Object System.Windows.Forms.Timer
    $script:GoblinUiTimer.Interval = 500
    $script:GoblinUiTimer.Add_Tick({ Refresh-GoblinMonitorGrid })

    $configureButton.Add_Click({
        if (Show-GoblinConnectionDialog) {
            Set-GoblinWorkerUiState
            if (-not $script:GoblinEngineRunning) { Start-StreamGoblinEngine | Out-Null }
        }
    })
    $script:GoblinToggleButton.Add_Click({
        if ($script:GoblinEngineRunning) { Stop-StreamGoblinEngine }
        else {
            if (-not $script:GoblinConfigured) {
                if (-not (Show-GoblinConnectionDialog)) { return }
            }
            Start-StreamGoblinEngine | Out-Null
        }
    })
    $openLogsButton.Add_Click({
        if (-not (Test-Path -LiteralPath $script:GoblinLogsDirectory)) { New-Item -ItemType Directory -Path $script:GoblinLogsDirectory -Force | Out-Null }
        Start-Process explorer.exe -ArgumentList ('"' + $script:GoblinLogsDirectory + '"')
    })
    $saveTargetsButton.Add_Click({
        if (Save-GoblinTargetsFromGrid) { Refresh-GoblinTargetGrid }
    })
    $changeTimesButton.Add_Click({ Edit-SelectedGoblinTimeRange })
    $script:GoblinTargetGrid.Add_CellDoubleClick({
        param($sender, $eventArgs)
        if ($eventArgs.RowIndex -lt 0 -or $eventArgs.ColumnIndex -lt 0) { return }
        $columnName = $sender.Columns[$eventArgs.ColumnIndex].Name
        if ($columnName -eq 'Username' -or $columnName -eq 'Minimum' -or $columnName -eq 'Maximum') {
            Edit-SelectedGoblinTimeRange
        }
    })
    $disableAllButton.Add_Click({
        foreach ($row in $script:GoblinTargetGrid.Rows) { $row.Cells['Enabled'].Value = $false }
        if (Save-GoblinTargetsFromGrid) { Refresh-GoblinTargetGrid }
    })
    $addUserButton.Add_Click({
        $name = Show-AddGoblinUserDialog
        if ([string]::IsNullOrWhiteSpace($name)) { return }
        foreach ($row in $script:GoblinTargetGrid.Rows) {
            if ([string]$row.Cells['Username'].Value -ieq $name) {
                $script:GoblinTargetGrid.CurrentCell = $row.Cells['Username']
                return
            }
        }
        $script:GoblinTargetGrid.Rows.Add($false, $name, 10, 15) | Out-Null
    })
}

function Initialize-StreamGoblinFeature {
    try {
        Initialize-GoblinConfiguration
        $script:GoblinErrorBox.Text = $script:GoblinErrorMessage
        Refresh-GoblinTargetGrid
        Load-GoblinRecentLog
        Set-GoblinWorkerUiState
        $script:GoblinUiTimer.Start()
        if ($script:GoblinConfigured) { Start-StreamGoblinEngine | Out-Null }
    }
    catch {
        $script:GoblinConfigured = $false
        $script:GoblinEngineRunning = $false
        Set-GoblinWorkerUiState
        Write-AppLog "Stream Goblin initialization failed: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show(
            "Stream Goblin could not initialize its local settings. User Access remains available and no Plex setting was changed.`r`n`r`n$($_.Exception.Message)",
            $script:AppName,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Close-StreamGoblinFeature {
    if ($null -ne $script:GoblinUiTimer) { $script:GoblinUiTimer.Stop() }
    Stop-StreamGoblinEngine -ApplicationClosing
}

PLEX GOBLIN PORTABLE DATA
=========================

This folder is intentionally empty in the Public Clean download. Plex Goblin
creates the local files below only after it runs.

Plex Goblin stores all of its active settings, encrypted keys, status, locks,
and logs inside this Data folder.

Keep this folder when updating or moving Plex Goblin. Do not copy individual
encrypted key files to a different computer or Windows account; Windows Data
Protection may require you to enter those keys again.

It is safe to inspect the text logs while Plex Goblin is closed. Avoid editing
configuration or status files while the application is running.

Never publicly redistribute this folder after running Plex Goblin. Share the
original Public Clean ZIP so no local users, settings, identifiers, keys, or
logs are included.

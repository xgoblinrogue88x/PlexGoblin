# Publishing Plex Goblin on GitHub

## Create the repository

1. On GitHub, create a new repository such as `plex-goblin`.
2. Choose **Public**.
3. Choose **None** in GitHub's license dropdown. This package already includes
   the custom combined `LICENSE` file that must be uploaded unchanged.
4. Extract `PlexGoblin-GitHub-3.2.0.zip`.
5. Upload the contents of the extracted folder so `README.md` appears at the
   repository root. Do not upload the outer folder as an extra directory.
6. Commit the files to the default branch.

Before committing, confirm that GitHub shows `Data/README.txt` but no other
file beneath `Data`.

## Create the 3.2.0 release

1. Open **Releases** and choose **Draft a new release**.
2. Create the tag `v3.2.0`.
3. Use the release title `Plex Goblin 3.2.0`.
4. Attach `PlexGoblin-3.2.0-Public-Clean.zip` as the downloadable asset.
5. Copy the 3.2.0 section from `CHANGELOG.md` into the release notes.
6. Publish the release.

The Public Clean ZIP is supplied separately from this repository package. Do
not rebuild it by compressing a Plex Goblin folder that has already been run.
That installed `Data` folder can contain local users, encrypted keys, settings,
server information, and logs.

## License display

The repository uses one `LICENSE` file containing the MIT terms plus the
Commons Clause no-sale condition. GitHub may identify this custom combination
as **Other** instead of MIT; that is expected. Do not replace it with GitHub's
plain MIT template, because plain MIT permits commercial sale.

The Commons Clause makes this a source-available project rather than an Open
Source Initiative-approved open-source project. Avoid describing it as
open-source in the repository or release notes.

## Final privacy check

- Do not upload an installed `Data` folder.
- Do not upload diagnostic logs or screenshots showing Plex users.
- Do not paste Plex or Tautulli credentials into issues or release notes.
- Keep `.gitignore` at the repository root.
- Keep the combined `LICENSE` file unchanged at the repository root.
- Attach only the official Public Clean ZIP to the release.

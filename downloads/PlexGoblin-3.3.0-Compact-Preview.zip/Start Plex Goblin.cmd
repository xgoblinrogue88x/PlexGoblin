@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0PlexGoblin.ps1"
if errorlevel 1 (
  echo.
  echo Plex Goblin could not start. See README.txt and this log:
  echo %~dp0Data\PlexGoblin.log
  echo.
  pause
)
endlocal

@echo off
setlocal
set "PLEXGOBLIN_HOME=%~dp0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
 "$desktop = [Environment]::GetFolderPath('Desktop'); $shell = New-Object -ComObject WScript.Shell; $shortcut = $shell.CreateShortcut((Join-Path $desktop 'Plex Goblin.lnk')); $shortcut.TargetPath = Join-Path $env:PLEXGOBLIN_HOME 'Start Plex Goblin.cmd'; $shortcut.WorkingDirectory = $env:PLEXGOBLIN_HOME; $shortcut.IconLocation = (Join-Path $env:PLEXGOBLIN_HOME 'PlexGoblin.ico') + ',0'; $shortcut.Description = 'Plex user-access controls plus integrated Stream and Monitor Goblin.'; $shortcut.Save()"

if errorlevel 1 (
  echo.
  echo The desktop shortcut could not be created.
) else (
  echo.
  echo Plex Goblin shortcut created on your desktop.
)
echo.
pause
endlocal
